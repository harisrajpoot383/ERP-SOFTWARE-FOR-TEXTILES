# 🚀 COMPLETE cPANEL DEPLOYMENT GUIDE
## Shifa Zahra Textiles ERP System

**Estimated Time:** 30-45 minutes  
**Difficulty:** ⭐⭐ (Easy to Medium)  
**Requirements:** Basic computer skills

---

## ✅ PRE-DEPLOYMENT CHECKLIST

Before starting, you must have:

- [ ] cPanel/Hosting account created
- [ ] Domain name pointing to your hosting
- [ ] Access to cPanel (login URL from hosting provider)
- [ ] `shifa-zahra-erp.zip` file downloaded
- [ ] Windows/Mac computer with internet access
- [ ] File extraction software (WinRAR, 7-Zip, or built-in)

**If you don't have these, STOP and contact your hosting provider.**

---

# PHASE 1: EXTRACT & PREPARE FILES (5 MINUTES)

## Step 1.1: Extract the ZIP File

**On Windows:**
1. Right-click `shifa-zahra-erp.zip`
2. Select **Extract All...**
3. Choose location (e.g., Desktop)
4. Click **Extract**
5. Wait for completion
6. A folder named `shifa-zahra-erp` will appear

**On Mac:**
1. Double-click `shifa-zahra-erp.zip`
2. It auto-extracts to the same folder
3. A folder named `shifa-zahra-erp` will appear

**✓ Verification:** You should see a folder with these subfolders:
```
shifa-zahra-erp/
├── app/
├── database/
├── resources/
├── routes/
├── public/
├── storage/
├── .env.example
├── .htaccess
├── composer.json
├── README.md
└── [other files]
```

## Step 1.2: Prepare for Upload

You'll be uploading:
1. **Everything inside** the `shifa-zahra-erp` folder to cPanel
2. NOT the folder itself, just its contents

Create a list of what you're uploading:
- ✓ `app/` folder
- ✓ `database/` folder  
- ✓ `resources/` folder
- ✓ `routes/` folder
- ✓ `public/` folder
- ✓ `storage/` folder
- ✓ `bootstrap/` folder (if present)
- ✓ `config/` folder (if present)
- ✓ All `.php`, `.json`, `.md` files

---

# PHASE 2: LOGIN TO cPANEL (2 MINUTES)

## Step 2.1: Access cPanel

1. Open your web browser (Chrome, Firefox, Safari, Edge)

2. Go to cPanel login page:
   ```
   https://your-domain.com:2083
   OR
   https://your-hosting-ip:2083
   OR
   Ask your hosting provider for the URL
   ```

3. You should see a login form

4. Enter:
   - **Username:** (provided by hosting)
   - **Password:** (provided by hosting)

5. Click **Login**

6. You should see the cPanel Dashboard (colorful icons for File Manager, MySQL, etc.)

**✓ Verification:** You're logged into cPanel if you see the main dashboard with folders icon, databases icon, etc.

---

# PHASE 3: CREATE DATABASE IN cPANEL (5 MINUTES)

## Step 3.1: Create Database

1. In cPanel, find and click **MySQL Databases**

   ![Location: Main cPanel page, usually under "Databases" section]

2. Under "Create New Database" section:

3. Enter database name:
   ```
   shifa_zahra_erp
   ```
   
   **Note:** Some hosting adds prefix automatically (e.g., `cpanel_shifa_zahra_erp`)
   **Write down the exact name shown:** ___________________

4. Click **Create Database**

5. You should see: **"Database shifa_zahra_erp created successfully"**

**✓ Verification:** Database appears in list below

## Step 3.2: Create Database User

1. Still in MySQL Databases page

2. Scroll down to "MySQL Users" section

3. Enter:
   - **Username:** `shifa_user`
   - **Password:** Create a strong password (min 8 chars, with numbers & symbols)
     
     **Example:** `Shifa@2024#Textiles`
     
     **Write it down:** ___________________
   
   - **Confirm Password:** (repeat the password)

4. Click **Create User**

5. You should see: **"User shifa_user created successfully"**

**✓ Verification:** User appears in "Current Users" list

## Step 3.3: Assign User to Database

1. Still on MySQL Databases page

2. Scroll to "Add User To Database"

3. Select:
   - **User:** `shifa_user`
   - **Database:** `shifa_zahra_erp`

4. Click **Add**

5. You should see checkboxes for permissions

6. Check **ALL PRIVILEGES** checkbox

7. Click **Make Changes**

8. You should see: **"User added to database successfully"**

**✓ Verification:** User now listed under the database with ALL permissions

## Step 3.4: Note Your Database Details

**WRITE THIS DOWN - YOU WILL NEED IT:**

```
Database Name:  shifa_zahra_erp
Database User:  shifa_user
Password:       [your password]
Hostname:       localhost
Port:           3306
```

---

# PHASE 4: UPLOAD FILES TO cPANEL (10 MINUTES)

## Step 4.1: Open File Manager

1. From cPanel Dashboard, click **File Manager**

2. A new window opens

3. You should see folders like:
   - `public_html`
   - `public_ftp`
   - `mail`
   - etc.

**Important:** We're uploading to `public_html` folder

## Step 4.2: Navigate to public_html

1. Double-click the `public_html` folder to enter it

2. You should see:
   - `index.html` (or `index.php`)
   - Maybe some existing files/folders

3. **BACKUP FIRST:** If there are existing files:
   - Select them
   - Right-click → **Compress**
   - Name it `backup-original.zip`
   - This saves your old website

## Step 4.3: Upload Project Files

1. In File Manager, look for **Upload** button (usually top left)

2. Click **Upload**

3. A file chooser dialog opens

4. Navigate to your extracted `shifa-zahra-erp` folder on your computer

5. Select ALL contents (Ctrl+A):
   ```
   app/
   database/
   resources/
   routes/
   public/ (the public folder)
   storage/
   .env.example
   .htaccess
   composer.json
   [all other files]
   ```

6. Click **Open** or **Upload**

7. **WAIT** for upload to complete (you'll see progress bar)

   ⏱️ This might take 2-3 minutes depending on connection speed

8. You should see: **"Upload complete"** or all files listed

**✓ Verification:** In File Manager, you now see:
```
public_html/
├── app/
├── database/
├── resources/
├── routes/
├── public/ ← Note: this is the public folder from the project
├── storage/
├── .env.example
├── .htaccess
└── [other files]
```

---

# PHASE 5: SET FOLDER PERMISSIONS (5 MINUTES)

These folders need special permissions for the system to write to them.

## Step 5.1: Set storage/ Permissions

1. In File Manager, find `storage` folder

2. Right-click on it → **Permissions**

3. You see checkboxes. Check these boxes:
   ```
   ☑ Owner: Read, Write, Execute (7)
   ☑ Group: Read, Write, Execute (7)
   ☑ Others: Read, Write, Execute (7)
   ```
   
   The number should show: **777**

4. Check the box: **"Apply to all files and folders within this directory"**

5. Click **Change**

6. You should see: **"Permissions updated"**

## Step 5.2: Set bootstrap/cache Permissions

1. Find `bootstrap` folder → Open it

2. Find `cache` folder inside

3. Right-click → **Permissions**

4. Set to **777** (all checkboxes checked)

5. Check **"Apply to all files and folders"**

6. Click **Change**

## Step 5.3: Set public Folder Permissions

1. Find the `public` folder (inside your uploaded files)

2. Right-click → **Permissions**

3. Set to **755** (not 777):
   ```
   ☑ Owner: Read, Write, Execute (7)
   ☑ Group: Read, Execute (5)
   ☑ Others: Read, Execute (5)
   ```

4. Do NOT check "Apply to all files"

5. Click **Change**

## Step 5.4: Verify Permissions

In File Manager, permissions should look like:
```
storage/        755 or 777 ✓
bootstrap/cache 755 or 777 ✓
public/         755        ✓
```

**✓ Verification:** No errors when accessing these folders

---

# PHASE 6: COPY & CONFIGURE .env FILE (5 MINUTES)

## Step 6.1: Find .env.example

1. In File Manager, in `public_html`, find `.env.example`

2. Right-click → **Copy**

3. Right-click in empty space → **Paste**

4. A file `copy of .env.example` appears (or similar)

5. Right-click on it → **Rename**

6. Change name to: `.env` (exactly)

7. Press Enter

**✓ Verification:** Now you have both `.env.example` and `.env` files

## Step 6.2: Edit .env File

1. Right-click `.env` file

2. Click **Edit** (or **Open with Code Editor**)

3. The file opens in a text editor

4. Find and modify these lines:

```
APP_NAME="Shifa Zahra Textiles ERP"
APP_ENV=production
APP_KEY=base64:xxxxx
APP_URL=https://yourdomain.com

DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=shifa_zahra_erp
DB_USERNAME=shifa_user
DB_PASSWORD=Shifa@2024#Textiles
```

**CHANGE THESE:**

| Line | Change To | Example |
|------|-----------|---------|
| `APP_URL` | Your domain | `https://shifazahratextiles.com` |
| `DB_DATABASE` | Your DB name | `shifa_zahra_erp` |
| `DB_USERNAME` | Your DB user | `shifa_user` |
| `DB_PASSWORD` | Your DB password | `Shifa@2024#Textiles` |

**Leave these unchanged:**
- `DB_HOST=localhost`
- `DB_CONNECTION=mysql`
- `DB_PORT=3306`

5. **IMPORTANT:** Leave `APP_KEY` line as is for now (we'll generate it next)

6. Scroll down and find:

```
MAIL_MAILER=smtp
MAIL_HOST=smtp.mailtrap.io
MAIL_PORT=2525
MAIL_USERNAME=
MAIL_PASSWORD=
```

These can be left as default (email is optional)

7. Scroll to bottom and add:

```
COMPANY_NAME="Shifa Zahra Textiles"
COMPANY_EMAIL="admin@shifazahratextiles.com"
COMPANY_CITY="Faisalabad"
CURRENCY=PKR
CURRENCY_SYMBOL=Rs.
```

8. Click **Save** or **Save Changes**

9. Editor closes

**✓ Verification:** File is saved with all your changes

---

# PHASE 7: IMPORT DATABASE SCHEMA (8 MINUTES)

## Step 7.1: Open phpMyAdmin

1. Go back to cPanel Dashboard

2. Find and click **phpMyAdmin**

3. A new window opens showing phpMyAdmin interface

4. You might see a login form:
   - **Username:** `shifa_user`
   - **Password:** (your database password)
   - Click **Go**

5. Or you're already logged in and see databases on left side

## Step 7.2: Select Your Database

1. On the left side, find your database:
   ```
   shifa_zahra_erp
   ```

2. Click on it

3. The database opens and shows "No tables" (it's empty, which is correct)

4. You see tabs at top: **Structure, SQL, Search, Insert, Export, Import**, etc.

## Step 7.3: Import the Schema

1. Click the **Import** tab

2. You see an upload area that says "Select file to upload"

3. Click **Browse** or **Choose File**

4. Navigate to your computer and find:
   ```
   shifa-zahra-erp/database/schema.sql
   ```

5. Select it and click **Open**

6. The file is selected, you see filename displayed

7. Scroll down and click the blue **Import** button

8. **WAIT...** The system imports the database

   ⏱️ This might take 30-60 seconds

9. You should see: **"Import successful"** message

10. The page refreshes and shows many tables in the left panel:
    ```
    accounts
    activity_logs
    attendance
    backup_logs
    categories
    customers
    employees
    expenses
    khata_entries
    login_logs
    notification
    ...
    users
    (about 40 tables total)
    ```

**✓ Verification:** You see all the tables listed on the left

## Step 7.4: Verify Users Table

1. Click on the `users` table on the left

2. Click **Browse** tab

3. You should see one row:
   ```
   ID: 1
   Name: Super Admin
   Email: admin@shifazahratextiles.com
   Password: (encrypted)
   Role ID: 1
   is_active: 1
   ```

4. This is your default admin account

**✓ Verification:** Admin user exists and is active

---

# PHASE 8: GENERATE APPLICATION KEY (3 MINUTES)

This is critical for the application to work.

## Step 8.1: Access Terminal (SSH)

This requires SSH access. Ask your hosting provider if you have it.

**If you have SSH:**
1. Open Terminal (Mac) or Command Prompt (Windows PowerShell or PuTTY)

2. Connect to your server:
   ```
   ssh username@yourdomain.com
   ```
   (Replace with your actual SSH credentials)

3. Navigate to public_html:
   ```
   cd public_html
   ```

4. Generate key:
   ```
   php artisan key:generate
   ```

5. You see: **"Application key set successfully"**

6. Exit:
   ```
   exit
   ```

**If you DON'T have SSH access:**

### Alternative Method (Without SSH):

1. Go to File Manager

2. Find `.env` file

3. Edit it (right-click → Edit)

4. Find the line: `APP_KEY=base64:xxxxx`

5. **If it's empty** or shows `base64:`, we need to generate it

6. You can manually generate using this method:
   - Go to an online Laravel key generator: https://generate-laravel-key.com/
   - Copy the generated key
   - Paste it into `.env` file

7. Save the file

**✓ Verification:** `.env` file has a value in `APP_KEY` line that starts with `base64:`

---

# PHASE 9: SETUP SSL CERTIFICATE (5 MINUTES)

This makes your site HTTPS (secure).

## Step 9.1: Enable AutoSSL

1. From cPanel Dashboard, find **AutoSSL** or **SSL/TLS**

2. Click it

3. You see your domain listed:
   ```
   yourdomain.com
   ```

4. Click **Install** or **Force SSL**

5. Wait for process to complete (usually instant)

6. You should see: **"Certificate installed successfully"** or checkmark ✓

**✓ Verification:** No errors shown

## Step 9.2: Update .env File

1. Go back to File Manager

2. Edit `.env` file again

3. Find line: `APP_URL=https://yourdomain.com`

4. Make sure it starts with `https://` (not `http://`)

5. Save file

---

# PHASE 10: CONFIGURE DOCUMENT ROOT (5 MINUTES)

This tells cPanel which folder is your website (the `public` folder).

## Step 10.1: Setup Addon Domain

**If this is a NEW domain:**

1. From cPanel, find **Addon Domains** (under "Domains" section)

2. Click it

3. Fill in:
   - **Domain Name:** yourdomain.com
   - **Document Root:** Leave as default OR change to `public_html`

4. Click **Add Domain**

**If this is your PRIMARY domain:**

1. From cPanel, find **Domains** or **Primary Domain**

2. The document root is usually already set to `public_html`

**If you need to change document root:**

1. From cPanel, find **Domains**

2. Find your domain

3. Click **Manage**

4. Change **Document Root** to: `/public_html/public`

5. Click **Update**

**✓ Verification:** Can access yourdomain.com and see a page (not blank)

---

# PHASE 11: TEST THE APPLICATION (5 MINUTES)

## Step 11.1: Access Your Site

1. Open browser

2. Go to: `https://yourdomain.com`

3. You should see the **Login Page**

**What you should see:**
```
Shifa Zahra Textiles ERP
[Email input field]
[Password input field]
[Sign In button]
```

**If you see:**
- ❌ "File not found" → Document root is wrong
- ❌ "Database connection error" → .env database settings wrong
- ❌ "Application error" → Check storage/logs/laravel.log
- ❌ Blank page → Check error logs

## Step 11.2: Login Test

1. Enter:
   - **Email:** `admin@shifazahratextiles.com`
   - **Password:** `Admin@123456`

2. Click **Sign In**

3. You should see the **Dashboard** with:
   - Analytics charts
   - Sales figures
   - Customer count
   - Sidebar menu

**✓ Verification:** Successfully logged in and see dashboard

## Step 11.3: Change Admin Password (CRITICAL)

**DO THIS IMMEDIATELY:**

1. Click your name/avatar in top right

2. Select **Change Password**

3. Enter:
   - **Current Password:** `Admin@123456`
   - **New Password:** (create a strong one)
   - **Confirm Password:** (repeat)

4. Click **Save**

5. You see: **"Password changed successfully"**

6. Logout and login with new password to verify

**✓ Verification:** New password works

---

# PHASE 12: BACKUP YOUR DATABASE (2 MINUTES)

## Step 12.1: Create First Backup

1. From your logged-in system, go to:
   **Settings → Backup & Restore**

2. Click **Create Backup** button

3. Wait for completion (might take 1-2 minutes)

4. You see: **"Backup created successfully"**

5. Download the backup file to your computer:
   - Click download icon next to the backup
   - Save to a safe location

**✓ Verification:** Backup file downloaded and saved

---

# PHASE 13: FINAL VERIFICATION CHECKLIST ✓

Go through this checklist to ensure everything is working:

## Technical Checks

- [ ] Can access domain in browser without errors
- [ ] SSL certificate working (HTTPS, green padlock)
- [ ] Can login with admin account
- [ ] Dashboard loads with data
- [ ] All menu items visible
- [ ] Database has all 40+ tables
- [ ] File permissions are correct (777 for storage, 755 for public)
- [ ] .env file configured correctly
- [ ] APP_KEY is set (not empty)

## Functional Checks

- [ ] Click on **POS** → Can access POS page
- [ ] Click on **Khata** → Can access Digital Khata
- [ ] Click on **Products** → Can view products list
- [ ] Click on **Customers** → Can view customers
- [ ] Click on **Suppliers** → Can view suppliers
- [ ] Click on **Accounting** → Can view accounts
- [ ] Click on **Settings** → Can view settings
- [ ] Click on **Backup** → Can see backup page
- [ ] Click your name → Can logout successfully

## Security Checks

- [ ] Changed default admin password ✓
- [ ] SSL certificate active ✓
- [ ] Cannot access .env file directly (try: yourdomain.com/.env) ✓
- [ ] Cannot access storage folder directly ✓

---

# PHASE 14: COMMON ISSUES & SOLUTIONS

## Issue: "Blank white page"

**Causes & Solutions:**

1. **Storage folder not writable:**
   ```
   Fix: Set storage/ to 777 permission
   ```

2. **APP_KEY not set:**
   ```
   Fix: Check .env has APP_KEY=base64:xxxxx
   ```

3. **Database not connected:**
   ```
   Fix: Check DB_HOST, DB_NAME, DB_USERNAME, DB_PASSWORD in .env
   Test in phpMyAdmin that you can login
   ```

4. **PHP version issue:**
   ```
   Fix: Ensure PHP 8.3+ 
   Check in cPanel PHP version
   ```

5. **Error logs:**
   ```
   Check File Manager: storage/logs/laravel.log
   Look at the errors shown
   ```

## Issue: "Database connection error"

**Check these:**

1. In phpMyAdmin, can you login with:
   - Username: shifa_user
   - Password: (your password)
   
   If NO → Database user not created correctly

2. In .env, verify:
   ```
   DB_HOST=localhost (NOT 127.0.0.1)
   DB_PORT=3306
   DB_DATABASE=shifa_zahra_erp (exact match)
   DB_USERNAME=shifa_user (exact match)
   DB_PASSWORD=your-password (matches what you set)
   ```

3. User has ALL privileges on database:
   - Open phpMyAdmin
   - Click database
   - Click Users tab
   - Verify shifa_user has all checkmarks

## Issue: "404 Not Found" / Page doesn't exist

**Causes:**

1. Document root pointing to wrong folder:
   ```
   Should be: /public_html OR /public_html/public
   NOT: /public_html/app or /public_html/database
   ```

2. .htaccess not working:
   ```
   Fix: Check mod_rewrite is enabled
   Contact hosting if needed
   ```

3. Try accessing: `https://yourdomain.com/index.php`
   ```
   If that works, .htaccess is the issue
   ```

## Issue: "Cannot write to storage/ or bootstrap/cache/"

**Fix:**

1. Go to File Manager

2. Right-click `storage/` → **Permissions**

3. Set to **777** (all boxes checked)

4. Check "Apply to all files and folders within this directory"

5. Click **Change**

Repeat for `bootstrap/cache/`

## Issue: "SSL certificate not working" / "https not available"

**Fix:**

1. Wait 15-30 minutes for AutoSSL to complete

2. Force redirect in .htaccess:
   ```
   In public/.htaccess, add:
   RewriteCond %{HTTPS} off
   RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
   ```

3. Contact hosting if still not working

## Issue: Login fails / "Invalid credentials"

**Check:**

1. Are you using exact credentials?
   - Email: `admin@shifazahratextiles.com` (case-sensitive)
   - Password: `Admin@123456`

2. Did you change password? (check notes you wrote down)

3. Check in phpMyAdmin that user record exists:
   - Open `users` table
   - Find the email `admin@shifazahratextiles.com`
   - Verify `is_active` = 1

---

# PHASE 15: POST-DEPLOYMENT TASKS

## Immediate (Today)

- [ ] Change admin password
- [ ] Create admin user account (Settings → Users)
- [ ] Test all main functions (POS, Khata)
- [ ] Create first database backup
- [ ] Download and save backup securely

## This Week

- [ ] Train staff on POS system
- [ ] Train staff on Khata module
- [ ] Add your company details (Settings → General)
- [ ] Add categories (Products → Categories)
- [ ] Create sample products

## This Month

- [ ] Hire developer to add remaining views (if not already done)
- [ ] Add actual product catalog
- [ ] Add customers and suppliers
- [ ] Configure payment accounts
- [ ] Monitor system for issues
- [ ] Create backup schedule

---

# COMPLETE TERMINAL COMMANDS (For Technical Users)

If you have SSH access, here are commands to speed things up:

```bash
# Connect to server
ssh username@yourdomain.com

# Navigate to project
cd public_html

# Copy .env
cp .env.example .env

# Generate application key
php artisan key:generate

# Set permissions
chmod -R 777 storage bootstrap/cache
chmod -R 755 app routes resources config database

# Clear cache (optional)
php artisan config:cache
php artisan cache:clear
```

---

# FINAL CHECKLIST - ARE YOU READY?

Before going live, verify:

```
DEPLOYMENT COMPLETE ✓

☑ Files uploaded to public_html
☑ Database created and imported
☑ .env file configured
☑ Permissions set (storage 777, bootstrap 777, public 755)
☑ APP_KEY generated
☑ SSL certificate installed
☑ Document root configured
☑ Can login with admin account
☑ Dashboard loads without errors
☑ Admin password changed
☑ First backup created and downloaded
☑ POS system accessible
☑ Khata module accessible
☑ All menu items working

STATUS: ✅ READY FOR PRODUCTION
```

---

# 📞 IF SOMETHING GOES WRONG

**Troubleshooting Steps (in order):**

1. Check `storage/logs/laravel.log` for error messages
2. Verify database connection in phpMyAdmin
3. Verify file permissions are correct
4. Check .env file for typos
5. Clear browser cache (Ctrl+Shift+Delete)
6. Try from incognito/private browser window
7. Contact your hosting provider
8. Check cPanel error logs (Errors section)

---

**🎉 YOU'RE NOW LIVE!**

Your Shifa Zahra Textiles ERP system is now accessible at: `https://yourdomain.com`

Default login:
- Email: admin@shifazahratextiles.com
- Password: (your new password)

**Next Steps:**
1. Train staff
2. Add products & customers
3. Start using POS system
4. Monitor performance
5. Create regular backups

**Congratulations on your new ERP system!** 🎊

---

**Support:** If you encounter issues, follow the troubleshooting guide above or contact your hosting provider.

**Remember:** Always keep backups!
