# 🎬 VISUAL cPANEL DEPLOYMENT FLOW

## Complete Deployment Timeline

```
START → [1] Extract ZIP → [2] Login cPanel → [3] Create Database
           (2 min)       (1 min)              (5 min)
                                                 ↓
[6] Configure .env ← [5] Upload Files ← [4] Set Permissions
   (5 min)           (10 min)              (5 min)
       ↓
[7] Import Schema → [8] Generate Key → [9] Setup SSL
   (5 min)          (3 min)            (2 min)
       ↓
[10] Configure Domain → [11] Test Login → [12] Change Password
     (3 min)            (3 min)           (2 min)
         ↓
     [13] Create Backup → SUCCESS! ✅
         (2 min)

TOTAL TIME: ~40-50 MINUTES

```

---

## PHASE-BY-PHASE BREAKDOWN

### 🔵 PHASE 1: PREPARATION (2 Minutes)
```
Action: Extract ZIP file
Tools Needed: WinRAR, 7-Zip, or Mac built-in
Expected Output: shifa-zahra-erp folder
Time: 2 minutes
Difficulty: ⭐ (Very Easy)
```

### 🟢 PHASE 2: cPANEL LOGIN (1 Minute)
```
Action: Access cPanel
URL: https://your-domain.com:2083
Method: Username + Password login
Expected: cPanel Dashboard appears
Time: 1 minute
Difficulty: ⭐ (Very Easy)
```

### 🟡 PHASE 3: CREATE DATABASE (5 Minutes)
```
Step 1: MySQL Databases → Create Database
        Name: shifa_zahra_erp
        
Step 2: MySQL Users → Create User
        User: shifa_user
        Password: [Your Strong Password]
        
Step 3: Add User to Database
        Assign shifa_user to shifa_zahra_erp
        Grant ALL privileges
        
Expected: All 3 items completed without errors
Time: 5 minutes
Difficulty: ⭐ (Very Easy)
```

### 🔴 PHASE 4: UPLOAD FILES (10 Minutes)
```
Action: Upload project files to public_html
Tool: File Manager (in cPanel)
Files: All contents of shifa-zahra-erp folder
Target Folder: public_html (not subfolders)

Upload list:
✓ app/
✓ database/
✓ resources/
✓ routes/
✓ public/
✓ storage/
✓ bootstrap/ (if present)
✓ All .php, .json, .md files

Expected: All files appear in public_html
Time: 10 minutes
Difficulty: ⭐⭐ (Easy)
```

### 🟣 PHASE 5: SET PERMISSIONS (5 Minutes)
```
Folders requiring 777 permission:
├─ storage/
├─ bootstrap/cache/

Folder requiring 755 permission:
├─ public/

Method: Right-click → Permissions → Set values
Expected: No error messages
Time: 5 minutes
Difficulty: ⭐⭐ (Easy)
```

### 🔵 PHASE 6: CONFIGURE .ENV (5 Minutes)
```
Action: Copy & edit .env file
Steps:
1. Copy .env.example → Rename to .env
2. Edit .env with your database details:
   - DB_DATABASE=shifa_zahra_erp
   - DB_USERNAME=shifa_user
   - DB_PASSWORD=YourPassword
   - APP_URL=https://yourdomain.com

Expected: File saved with correct values
Time: 5 minutes
Difficulty: ⭐⭐ (Easy)
```

### 🟢 PHASE 7: IMPORT SCHEMA (8 Minutes)
```
Action: Create database tables
Tool: phpMyAdmin
Steps:
1. Open phpMyAdmin from cPanel
2. Select database shifa_zahra_erp
3. Click Import tab
4. Upload database/schema.sql
5. Click Import

Expected: "Import successful" message
         40+ tables appear in database
Time: 8 minutes
Difficulty: ⭐⭐ (Easy)
```

### 🟡 PHASE 8: GENERATE KEY (3 Minutes)
```
Action: Generate application encryption key
Method: SSH command or online generator
Command: php artisan key:generate

Expected: APP_KEY in .env is set (not empty)
Time: 3 minutes
Difficulty: ⭐⭐ (Easy-Medium)
```

### 🟠 PHASE 9: SETUP SSL (5 Minutes)
```
Action: Install SSL certificate
Tool: AutoSSL in cPanel
Steps:
1. Click AutoSSL
2. Select your domain
3. Click Install or Force SSL
4. Wait for completion

Expected: Certificate installed
         Browser shows green padlock
Time: 5 minutes
Difficulty: ⭐ (Very Easy)
```

### 🔴 PHASE 10: CONFIGURE DOMAIN (5 Minutes)
```
Action: Set document root
Method: Addon Domains or Domain settings
Value: Set to /public_html/public (or /public_html)

Expected: Domain points to correct folder
Time: 5 minutes
Difficulty: ⭐⭐ (Easy)
```

### 🟣 PHASE 11: TEST LOGIN (5 Minutes)
```
Action: Verify application works
URL: https://yourdomain.com
Credentials:
  Email: admin@shifazahratextiles.com
  Password: Admin@123456

Expected: Login successful
         Dashboard displays with charts
Time: 5 minutes
Difficulty: ⭐ (Very Easy)
```

### 🔵 PHASE 12: CHANGE PASSWORD (2 Minutes)
```
Action: Secure admin account
Steps:
1. Login with default credentials
2. Click your name → Change Password
3. Enter new password (min 8 chars)
4. Save

Expected: Password changed successfully
         Can re-login with new password
Time: 2 minutes
Difficulty: ⭐ (Very Easy)
```

### 🟢 PHASE 13: CREATE BACKUP (2 Minutes)
```
Action: Backup database
Steps:
1. Go to Settings → Backup & Restore
2. Click Create Backup
3. Download backup file
4. Save to safe location

Expected: Backup file downloaded
Time: 2 minutes
Difficulty: ⭐ (Very Easy)
```

---

## DECISION TREE (When Things Go Wrong)

```
❌ BLANK PAGE?
├─ Check storage/ is 777? → NO: Fix permissions
├─ Check .env has APP_KEY? → NO: Generate key
├─ Check database connected? → NO: Verify credentials
└─ Check error logs? → File Manager → storage/logs/laravel.log

❌ DATABASE ERROR?
├─ Can login to phpMyAdmin? → NO: Check DB user credentials
├─ User has ALL privileges? → NO: Assign privileges
└─ Database has tables? → NO: Import schema.sql

❌ 404 ERROR / Page not found?
├─ Document root correct? → NO: Set to /public_html/public
├─ mod_rewrite enabled? → NO: Contact hosting
└─ .htaccess present? → NO: Upload .htaccess file

❌ LOGIN FAILS?
├─ Using exact credentials? → Check email & password
├─ User record exists? → Check users table in phpMyAdmin
└─ User is active? → Check is_active column = 1

❌ SSL NOT WORKING?
├─ Wait 30 minutes? → AutoSSL still processing
├─ DNS propagated? → Check domain pointing to server
└─ Certificate installed? → Check AutoSSL status
```

---

## ROLE-BASED RESPONSIBILITY BREAKDOWN

### If You're The Business Owner

**Just Need To Know:**

1. Give your IT person the ZIP file
2. Provide hosting cPanel credentials
3. Verify it works by logging in
4. Train staff to use it
5. **Don't try to do technical steps yourself** (unless IT person)

**Time Investment:** 5 minutes

---

### If You're The IT Person / Technical

**Need To Do All 13 Phases:**

Follow the complete guide exactly as written.

**Time Investment:** 45-60 minutes

**Knowledge Required:** Basic Linux/server skills, comfortable with command line (optional)

---

### If You're Hiring Someone To Do This

**What To Tell Them:**

> "Deploy Shifa Zahra Textiles Laravel ERP to cPanel hosting. Use the provided guide at CPANEL_DEPLOYMENT_GUIDE.md. Complete all 13 phases, test login, and provide verification that the system is working."

**Expected Cost:** FREE (they should know how to do this) or $50-100 (if outsourcing)

**Expected Time:** 1-2 hours

---

## CRITICAL SUCCESS FACTORS

These MUST be done correctly or system won't work:

| Item | Why Critical | Impact if Wrong |
|------|-------------|-----------------|
| Database credentials in .env | System connects to data | "Database connection error" |
| storage/ folder 777 permission | System writes logs | "Cannot write to storage" |
| APP_KEY generated | Data encryption | "Application key missing" |
| schema.sql imported | Tables created | "Table not found" error |
| .env copied from .example | Configuration loaded | Blank page |
| Document root set correctly | Web server serves app | 404 errors |
| SSL certificate installed | HTTPS works | "Not secure" warning |
| Admin user exists in DB | Login works | Cannot access system |

**All 8 of these MUST be correct for system to work.**

---

## VERIFICATION CHECKLIST

After deployment, verify each step:

### Step 1: Access Domain ✓
```
Go to: https://yourdomain.com
Expected: Login page loads
Result: ✓ YES / ✗ NO
```

### Step 2: SSL Working ✓
```
Look for green padlock 🔒 in browser address bar
Result: ✓ YES / ✗ NO
```

### Step 3: Login Works ✓
```
Email: admin@shifazahratextiles.com
Password: Admin@123456
Expected: Dashboard loads with charts
Result: ✓ YES / ✗ NO
```

### Step 4: Database Connected ✓
```
Check that numbers display on dashboard:
- Total Sales
- Today Sales
- Total Customers
etc.
Result: ✓ YES / ✗ NO
```

### Step 5: All Menu Items Present ✓
```
Sidebar should show:
- Dashboard
- POS
- Khata
- Products
- Customers
- Suppliers
- Sales
- Purchases
- Expenses
- Accounting
- Reports
- Settings
Result: ✓ YES / ✗ NO
```

### Step 6: Can Click Menu Items ✓
```
Try clicking:
- POS → Should load POS interface
- Khata → Should load Khata page
- Products → Should load Products list
Result: ✓ YES / ✗ NO
```

### Step 7: Logout Works ✓
```
Click your name → Logout
Expected: Redirected to login page
Result: ✓ YES / ✗ NO
```

### Step 8: Can Re-login ✓
```
Login again with your NEW password
(the one you changed to)
Result: ✓ YES / ✗ NO
```

**If ALL 8 are ✓:** YOUR SYSTEM IS READY FOR PRODUCTION! 🎉

---

## COMMON MISTAKES TO AVOID

❌ **MISTAKE #1:** Uploading to wrong folder
```
RIGHT: public_html/app, public_html/database, etc.
WRONG: public_html/shifa-zahra-erp/app
WRONG: public_html/shifa-zahra-erp/database
```

❌ **MISTAKE #2:** Setting wrong permissions
```
RIGHT: storage/ = 777, public/ = 755
WRONG: storage/ = 755, public/ = 777
WRONG: Everything = 777
```

❌ **MISTAKE #3:** Forgetting to generate APP_KEY
```
If APP_KEY is empty → Application won't load
Always generate: php artisan key:generate
```

❌ **MISTAKE #4:** Wrong database credentials in .env
```
Check EXACT spelling and case
DB_DATABASE must match what you created
DB_USERNAME must match what you created
DB_PASSWORD must match what you set
```

❌ **MISTAKE #5:** Not changing default password
```
DEFAULT: Admin@123456
This is KNOWN to everyone
Change immediately after first login!
```

❌ **MISTAKE #6:** Using HTTP instead of HTTPS
```
RIGHT: https://yourdomain.com
WRONG: http://yourdomain.com
Always use HTTPS after SSL setup
```

---

## SUCCESS INDICATORS

**System is working correctly when you see:**

✅ Login page at https://yourdomain.com  
✅ Can login with admin credentials  
✅ Dashboard displays without errors  
✅ Charts and numbers show on dashboard  
✅ All menu items appear in sidebar  
✅ Can navigate between pages  
✅ No error messages in console  
✅ "Connection successful" when logging  

**System has issues if:**

❌ Blank/white page  
❌ "Database connection error"  
❌ "Application key missing"  
❌ "Table not found"  
❌ 404 errors on pages  
❌ Cannot access any menu items  
❌ Logout button doesn't work  
❌ Files won't upload  

---

## ESTIMATED TIME BREAKDOWN

| Phase | Task | Time | Cumulative |
|-------|------|------|------------|
| 1 | Extract ZIP | 2 min | 2 min |
| 2 | Login cPanel | 1 min | 3 min |
| 3 | Create Database | 5 min | 8 min |
| 4 | Upload Files | 10 min | 18 min |
| 5 | Set Permissions | 5 min | 23 min |
| 6 | Configure .env | 5 min | 28 min |
| 7 | Import Schema | 8 min | 36 min |
| 8 | Generate Key | 3 min | 39 min |
| 9 | Setup SSL | 5 min | 44 min |
| 10 | Configure Domain | 3 min | 47 min |
| 11 | Test Login | 5 min | 52 min |
| 12 | Change Password | 2 min | 54 min |
| 13 | Create Backup | 2 min | 56 min |

**TOTAL: ~1 HOUR (with no issues)**

---

## NEXT STEPS AFTER SUCCESSFUL DEPLOYMENT

```
IMMEDIATELY:
├─ ✓ Change admin password
├─ ✓ Test POS system (attempt a test sale)
├─ ✓ Test Khata (add test entry)
└─ ✓ Create backup and download

TODAY:
├─ ✓ Add your company name (Settings)
├─ ✓ Set currency to PKR
├─ ✓ Configure payment accounts
└─ ✓ Create user accounts for staff

THIS WEEK:
├─ ✓ Add product categories
├─ ✓ Add sample products
├─ ✓ Add customers and suppliers
├─ ✓ Train staff on POS
└─ ✓ Train staff on Khata

THIS MONTH:
├─ ✓ Start using system for real sales
├─ ✓ Create daily backups
├─ ✓ Monitor for issues
└─ ✓ Hire developer if views need completion
```

---

**🎊 YOU NOW HAVE A COMPLETE DEPLOYMENT GUIDE!**

Follow it step by step and your system will be live in ~1 hour.

Questions? Refer back to **CPANEL_DEPLOYMENT_GUIDE.md** for detailed instructions on each step.

Good luck! 🚀
