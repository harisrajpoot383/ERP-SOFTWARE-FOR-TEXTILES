<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\CustomerController;
use App\Http\Controllers\Admin\SupplierController;
use App\Http\Controllers\Admin\SaleController;
use App\Http\Controllers\Admin\PurchaseController;
use App\Http\Controllers\Admin\ExpenseController;
use App\Http\Controllers\Admin\EmployeeController;
use App\Http\Controllers\Admin\AccountController;
use App\Http\Controllers\Admin\ReportController;
use App\Http\Controllers\Admin\SettingController;
use App\Http\Controllers\Admin\BackupController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\NotificationController;
use App\Http\Controllers\POS\PosController;
use App\Http\Controllers\Khata\KhataController;
use App\Http\Controllers\AuthController;

// ============================================================
// AUTHENTICATION ROUTES
// ============================================================
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.post');
});

Route::post('/logout', [AuthController::class, 'logout'])
    ->middleware('auth')
    ->name('logout');

// ============================================================
// AUTHENTICATED ROUTES
// ============================================================
Route::middleware(['auth', 'active.user'])->group(function () {

    // Force password change on first login
    Route::middleware('must.change.password')->group(function () {
        Route::get('/change-password', [AuthController::class, 'showChangePassword'])->name('password.change');
        Route::post('/change-password', [AuthController::class, 'changePassword'])->name('password.update');
    });

    // ============================================================
    // DASHBOARD
    // ============================================================
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard', [DashboardController::class, 'index']);
    Route::get('/dashboard/stats', [DashboardController::class, 'getStats'])->name('dashboard.stats');
    Route::get('/dashboard/charts', [DashboardController::class, 'getCharts'])->name('dashboard.charts');

    // ============================================================
    // POS SYSTEM
    // ============================================================
    Route::prefix('pos')->name('pos.')->group(function () {
        Route::get('/', [PosController::class, 'index'])->name('index');
        Route::post('/search-products', [PosController::class, 'searchProducts'])->name('search.products');
        Route::get('/product/{id}', [PosController::class, 'getProduct'])->name('product');
        Route::post('/hold-sale', [PosController::class, 'holdSale'])->name('hold');
        Route::get('/held-sales', [PosController::class, 'heldSales'])->name('held');
        Route::post('/resume-sale/{id}', [PosController::class, 'resumeSale'])->name('resume');
        Route::post('/complete-sale', [PosController::class, 'completeSale'])->name('complete');
        Route::get('/invoice/{id}', [PosController::class, 'invoice'])->name('invoice');
        Route::get('/invoice/{id}/print', [PosController::class, 'printInvoice'])->name('invoice.print');
        Route::get('/invoice/{id}/pdf', [PosController::class, 'downloadPdf'])->name('invoice.pdf');
        Route::get('/invoice/{id}/thermal', [PosController::class, 'thermalReceipt'])->name('invoice.thermal');
        Route::post('/apply-coupon', [PosController::class, 'applyCoupon'])->name('coupon');
        Route::post('/auto-save', [PosController::class, 'autoSave'])->name('autosave');
        Route::get('/draft', [PosController::class, 'getDraft'])->name('draft');
        Route::post('/return', [PosController::class, 'processReturn'])->name('return');
        Route::get('/barcode/{barcode}', [PosController::class, 'scanBarcode'])->name('barcode');
    });

    // ============================================================
    // KHATA SYSTEM
    // ============================================================
    Route::prefix('khata')->name('khata.')->group(function () {
        Route::get('/', [KhataController::class, 'index'])->name('index');
        Route::get('/customers', [KhataController::class, 'customers'])->name('customers');
        Route::get('/customer/{id}', [KhataController::class, 'customerLedger'])->name('customer.ledger');
        Route::post('/customer/{id}/entry', [KhataController::class, 'addCustomerEntry'])->name('customer.entry');
        Route::get('/suppliers', [KhataController::class, 'suppliers'])->name('suppliers');
        Route::get('/supplier/{id}', [KhataController::class, 'supplierLedger'])->name('supplier.ledger');
        Route::post('/supplier/{id}/entry', [KhataController::class, 'addSupplierEntry'])->name('supplier.entry');
        Route::get('/customer/{id}/pdf', [KhataController::class, 'customerPdf'])->name('customer.pdf');
        Route::get('/supplier/{id}/pdf', [KhataController::class, 'supplierPdf'])->name('supplier.pdf');
        Route::get('/summary', [KhataController::class, 'summary'])->name('summary');
    });

    // ============================================================
    // PRODUCTS / INVENTORY
    // ============================================================
    Route::prefix('products')->name('products.')->group(function () {
        Route::get('/', [ProductController::class, 'index'])->name('index');
        Route::get('/create', [ProductController::class, 'create'])->name('create');
        Route::post('/', [ProductController::class, 'store'])->name('store');
        Route::get('/{id}/edit', [ProductController::class, 'edit'])->name('edit');
        Route::put('/{id}', [ProductController::class, 'update'])->name('update');
        Route::delete('/{id}', [ProductController::class, 'destroy'])->name('destroy');
        Route::get('/{id}/barcode', [ProductController::class, 'barcode'])->name('barcode');
        Route::post('/adjust-stock', [ProductController::class, 'adjustStock'])->name('adjust');
        Route::get('/low-stock', [ProductController::class, 'lowStock'])->name('low-stock');
        Route::get('/categories', [ProductController::class, 'categories'])->name('categories');
        Route::post('/categories', [ProductController::class, 'storeCategory'])->name('categories.store');
        Route::get('/export', [ProductController::class, 'export'])->name('export');
    });

    // ============================================================
    // CUSTOMERS
    // ============================================================
    Route::prefix('customers')->name('customers.')->group(function () {
        Route::get('/', [CustomerController::class, 'index'])->name('index');
        Route::get('/create', [CustomerController::class, 'create'])->name('create');
        Route::post('/', [CustomerController::class, 'store'])->name('store');
        Route::get('/{id}', [CustomerController::class, 'show'])->name('show');
        Route::get('/{id}/edit', [CustomerController::class, 'edit'])->name('edit');
        Route::put('/{id}', [CustomerController::class, 'update'])->name('update');
        Route::delete('/{id}', [CustomerController::class, 'destroy'])->name('destroy');
        Route::get('/{id}/statement', [CustomerController::class, 'statement'])->name('statement');
        Route::get('/{id}/statement/pdf', [CustomerController::class, 'statementPdf'])->name('statement.pdf');
        Route::get('/search', [CustomerController::class, 'search'])->name('search');
    });

    // ============================================================
    // SUPPLIERS
    // ============================================================
    Route::prefix('suppliers')->name('suppliers.')->group(function () {
        Route::get('/', [SupplierController::class, 'index'])->name('index');
        Route::get('/create', [SupplierController::class, 'create'])->name('create');
        Route::post('/', [SupplierController::class, 'store'])->name('store');
        Route::get('/{id}', [SupplierController::class, 'show'])->name('show');
        Route::get('/{id}/edit', [SupplierController::class, 'edit'])->name('edit');
        Route::put('/{id}', [SupplierController::class, 'update'])->name('update');
        Route::delete('/{id}', [SupplierController::class, 'destroy'])->name('destroy');
        Route::get('/{id}/statement', [SupplierController::class, 'statement'])->name('statement');
    });

    // ============================================================
    // SALES
    // ============================================================
    Route::prefix('sales')->name('sales.')->group(function () {
        Route::get('/', [SaleController::class, 'index'])->name('index');
        Route::get('/{id}', [SaleController::class, 'show'])->name('show');
        Route::get('/{id}/invoice', [SaleController::class, 'invoice'])->name('invoice');
        Route::post('/{id}/return', [SaleController::class, 'return'])->name('return');
        Route::delete('/{id}', [SaleController::class, 'destroy'])->name('destroy');
        Route::get('/export/pdf', [SaleController::class, 'exportPdf'])->name('export.pdf');
        Route::get('/export/excel', [SaleController::class, 'exportExcel'])->name('export.excel');
    });

    // ============================================================
    // PURCHASES
    // ============================================================
    Route::prefix('purchases')->name('purchases.')->group(function () {
        Route::get('/', [PurchaseController::class, 'index'])->name('index');
        Route::get('/create', [PurchaseController::class, 'create'])->name('create');
        Route::post('/', [PurchaseController::class, 'store'])->name('store');
        Route::get('/{id}', [PurchaseController::class, 'show'])->name('show');
        Route::get('/{id}/edit', [PurchaseController::class, 'edit'])->name('edit');
        Route::put('/{id}', [PurchaseController::class, 'update'])->name('update');
        Route::delete('/{id}', [PurchaseController::class, 'destroy'])->name('destroy');
        Route::post('/{id}/payment', [PurchaseController::class, 'addPayment'])->name('payment');
        Route::post('/auto-save', [PurchaseController::class, 'autoSave'])->name('autosave');
    });

    // ============================================================
    // EXPENSES
    // ============================================================
    Route::prefix('expenses')->name('expenses.')->group(function () {
        Route::get('/', [ExpenseController::class, 'index'])->name('index');
        Route::get('/create', [ExpenseController::class, 'create'])->name('create');
        Route::post('/', [ExpenseController::class, 'store'])->name('store');
        Route::get('/{id}/edit', [ExpenseController::class, 'edit'])->name('edit');
        Route::put('/{id}', [ExpenseController::class, 'update'])->name('update');
        Route::delete('/{id}', [ExpenseController::class, 'destroy'])->name('destroy');
        Route::get('/categories', [ExpenseController::class, 'categories'])->name('categories');
        Route::get('/export', [ExpenseController::class, 'export'])->name('export');
    });

    // ============================================================
    // EMPLOYEES
    // ============================================================
    Route::prefix('employees')->name('employees.')->group(function () {
        Route::get('/', [EmployeeController::class, 'index'])->name('index');
        Route::get('/create', [EmployeeController::class, 'create'])->name('create');
        Route::post('/', [EmployeeController::class, 'store'])->name('store');
        Route::get('/{id}', [EmployeeController::class, 'show'])->name('show');
        Route::get('/{id}/edit', [EmployeeController::class, 'edit'])->name('edit');
        Route::put('/{id}', [EmployeeController::class, 'update'])->name('update');
        Route::delete('/{id}', [EmployeeController::class, 'destroy'])->name('destroy');
        Route::get('/attendance', [EmployeeController::class, 'attendance'])->name('attendance');
        Route::post('/attendance', [EmployeeController::class, 'markAttendance'])->name('attendance.mark');
        Route::get('/salary', [EmployeeController::class, 'salary'])->name('salary');
        Route::post('/salary', [EmployeeController::class, 'paySalary'])->name('salary.pay');
    });

    // ============================================================
    // ACCOUNTING
    // ============================================================
    Route::prefix('accounting')->name('accounting.')->group(function () {
        Route::get('/', [AccountController::class, 'index'])->name('index');
        Route::get('/accounts', [AccountController::class, 'accounts'])->name('accounts');
        Route::post('/accounts', [AccountController::class, 'storeAccount'])->name('accounts.store');
        Route::get('/cash-book', [AccountController::class, 'cashBook'])->name('cashbook');
        Route::get('/journal', [AccountController::class, 'journal'])->name('journal');
        Route::post('/journal', [AccountController::class, 'storeJournal'])->name('journal.store');
        Route::get('/transfer', [AccountController::class, 'transfer'])->name('transfer');
        Route::post('/transfer', [AccountController::class, 'doTransfer'])->name('transfer.do');
    });

    // ============================================================
    // REPORTS
    // ============================================================
    Route::prefix('reports')->name('reports.')->group(function () {
        Route::get('/', [ReportController::class, 'index'])->name('index');
        Route::get('/sales', [ReportController::class, 'sales'])->name('sales');
        Route::get('/purchases', [ReportController::class, 'purchases'])->name('purchases');
        Route::get('/profit-loss', [ReportController::class, 'profitLoss'])->name('profit.loss');
        Route::get('/inventory', [ReportController::class, 'inventory'])->name('inventory');
        Route::get('/customers', [ReportController::class, 'customers'])->name('customers');
        Route::get('/suppliers', [ReportController::class, 'suppliers'])->name('suppliers');
        Route::get('/expenses', [ReportController::class, 'expenses'])->name('expenses');
        Route::get('/cash-flow', [ReportController::class, 'cashFlow'])->name('cashflow');
        Route::get('/credit-recovery', [ReportController::class, 'creditRecovery'])->name('credit');
        Route::get('/khata', [ReportController::class, 'khata'])->name('khata');
        Route::get('/daily-sales', [ReportController::class, 'dailySales'])->name('daily');
        // Export
        Route::get('/{type}/pdf', [ReportController::class, 'exportPdf'])->name('pdf');
        Route::get('/{type}/excel', [ReportController::class, 'exportExcel'])->name('excel');
    });

    // ============================================================
    // SETTINGS
    // ============================================================
    Route::prefix('settings')->name('settings.')->middleware('role:super-admin')->group(function () {
        Route::get('/', [SettingController::class, 'index'])->name('index');
        Route::post('/', [SettingController::class, 'update'])->name('update');
        Route::get('/users', [UserController::class, 'index'])->name('users');
        Route::get('/users/create', [UserController::class, 'create'])->name('users.create');
        Route::post('/users', [UserController::class, 'store'])->name('users.store');
        Route::get('/users/{id}/edit', [UserController::class, 'edit'])->name('users.edit');
        Route::put('/users/{id}', [UserController::class, 'update'])->name('users.update');
        Route::delete('/users/{id}', [UserController::class, 'destroy'])->name('users.destroy');
        Route::get('/activity-log', [SettingController::class, 'activityLog'])->name('activity');
        Route::get('/login-log', [SettingController::class, 'loginLog'])->name('loginlog');
    });

    // ============================================================
    // BACKUPS
    // ============================================================
    Route::prefix('backup')->name('backup.')->middleware('role:super-admin')->group(function () {
        Route::get('/', [BackupController::class, 'index'])->name('index');
        Route::post('/create', [BackupController::class, 'create'])->name('create');
        Route::get('/{filename}/download', [BackupController::class, 'download'])->name('download');
        Route::post('/{filename}/restore', [BackupController::class, 'restore'])->name('restore');
        Route::delete('/{filename}', [BackupController::class, 'delete'])->name('delete');
    });

    // ============================================================
    // NOTIFICATIONS
    // ============================================================
    Route::prefix('notifications')->name('notifications.')->group(function () {
        Route::get('/', [NotificationController::class, 'index'])->name('index');
        Route::post('/{id}/read', [NotificationController::class, 'markRead'])->name('read');
        Route::post('/read-all', [NotificationController::class, 'markAllRead'])->name('read.all');
        Route::get('/unread-count', [NotificationController::class, 'unreadCount'])->name('count');
    });
});
