# QUICK REFERENCE GUIDE

## 🎯 COMMON TASKS

### Creating a Sale
1. Go to **POS** → Point of Sale
2. Select customer (or "Walk-in Customer")
3. Search products by name/SKU/barcode
4. Add items to cart
5. Set discount if needed
6. Apply coupon (optional)
7. Select payment method(s)
8. Complete sale
9. Print/Send invoice

**Time: 2-3 minutes per sale**

### Recording Payment from Customer
1. Go to **Khata** → Customers
2. Select customer
3. Click "Add Payment"
4. Enter amount
5. Select account (Cash/Bank/Easypaisa/JazzCash)
6. Save
7. Balance automatically updated

### Creating Purchase Order
1. Go to **Purchases** → New Purchase
2. Select supplier
3. Add products from catalog
4. Enter quantities
5. Check calculated total
6. Set due date
7. Save
8. Receive goods, update inventory

### Viewing Khata/Ledger
1. Go to **Khata** → Digital Khata
2. Select Customers or Suppliers
3. Click customer name
4. See running ledger with balances
5. Export as PDF for record

### Generating Reports
1. Go to **Reports** → Select Report Type
   - Sales Report
   - Profit & Loss
   - Inventory Report
   - Customer Aging
   - Supplier Balance
   - Expense Report
2. Select date range
3. View/Export as PDF or Excel

### Adding New Product
1. Go to **Products** → New Product
2. Fill details:
   - Name, SKU, Barcode
   - Category
   - Cost Price, Sale Price
   - Stock Quantity
   - Minimum Stock Alert
3. Add variants (size, color) if applicable
4. Upload image
5. Save

### Adjusting Inventory
1. Go to **Products** → Adjust Stock
2. Search product
3. Enter quantity change
4. Select reason (damage, loss, correction, etc.)
5. Save adjustment
6. Stock updated automatically

### Downloading Backup
1. Go to **Settings** → Backup & Restore
2. Click "Create Backup" (manual) or view existing
3. Click download icon next to backup
4. Save file to secure location
5. Test restore monthly

### Restoring from Backup
1. Go to **Settings** → Backup & Restore
2. Select backup from list
3. Click "Restore"
4. ⚠️ **WARNING:** This overwrites current data
5. Confirm
6. System restores to that date/time

### Adding New User
1. Go to **Settings** → Users
2. Click "Add User"
3. Fill:
   - Name
   - Email
   - Role (Cashier, Manager, Accountant, etc.)
   - Password
4. User can change password on first login
5. Assign to department/store

### Changing Password
1. Click your name (top right)
2. Select "Change Password"
3. Enter current password
4. Enter new password (min 8 chars)
5. Confirm
6. Save

### Viewing Activity Log
1. Go to **Settings** → Activity Log
2. See all system actions with timestamp
3. Shows who did what and when
4. Useful for audit trail

### Configuring Settings
1. Go to **Settings** → General
2. Update:
   - Company name & details
   - Currency & tax rates
   - Low stock threshold
   - Invoice prefix
   - Email/WhatsApp settings
3. Save

---

## 📱 COMMON SHORTCUTS

| Action | Shortcut |
|--------|----------|
| POS Page | `/pos` |
| Khata | `/khata` |
| Products | `/products` |
| Customers | `/customers` |
| Suppliers | `/suppliers` |
| Sales | `/sales` |
| Purchases | `/purchases` |
| Reports | `/reports` |
| Accounting | `/accounting` |
| Settings | `/settings` |
| Dashboard | `/` or `/dashboard` |

---

## 🔍 FREQUENTLY ASKED QUESTIONS

### Q: How do I print receipts?
**A:** After completing a sale in POS, click "Print Receipt" or "Print A4 Invoice" on the receipt page.

### Q: Can I edit a sale after it's completed?
**A:** Direct editing is limited for audit purposes. Use "Return" option to reverse and create new sale.

### Q: How is profit calculated?
**A:** Profit = Sale Price - Cost Price (per item). Total profit calculated automatically per sale.

### Q: What if a customer pays partial amount?
**A:** The system marks it as "Partial" and remaining balance moves to Khata for follow-up payment.

### Q: How do I void/cancel a sale?
**A:** Create a "Return" for the entire sale. Stock and balance reversed automatically.

### Q: Can I backup to cloud?
**A:** Current version uses local backups. Download regularly and store on external drive or cloud storage.

### Q: How often should I backup?
**A:** Daily automatic backups enabled. Download backups weekly for off-site storage.

### Q: What happens if I restore from old backup?
**A:** All data created after that backup date is lost. Only restore if absolutely necessary.

### Q: Can multiple users use POS simultaneously?
**A:** Yes! Each cashier can have their own login. All transactions tracked separately.

### Q: How do I track which cashier made which sale?
**A:** Every sale shows the user who created it. Check Settings → Activity Log for details.

### Q: Can I give staff access to only certain features?
**A:** Yes! Roles control this. Assign appropriate role when creating user account.

---

## ⚠️ CRITICAL REMINDERS

1. **CHANGE DEFAULT ADMIN PASSWORD** immediately after first login
2. **TEST BACKUP RESTORE** at least monthly
3. **DOWNLOAD BACKUPS** off-site weekly
4. **KEEP SSL CERTIFICATE UPDATED** to prevent HTTPS warnings
5. **MONITOR STORAGE SPACE** - backups consume disk space
6. **UPDATE PASSWORDS** for inactive users (disable accounts instead)
7. **REVIEW ACTIVITY LOG** monthly for suspicious activity
8. **KEEP COMPOSER.JSON** - needed for future updates

---

## 🐛 TROUBLESHOOTING QUICK TIPS

| Issue | Solution |
|-------|----------|
| Blank page | Check `storage/logs/laravel.log` |
| Can't login | Verify credentials, check failed login attempts |
| Slow performance | Clear cache: Settings → Maintenance |
| Backup fails | Check `storage/backups/` folder permissions (777) |
| Missing invoices | Verify sale status is "completed" not "hold" or "cancelled" |
| Stock mismatch | Check stock adjustment logs |
| Missing payment | Verify payment was linked to sale, check all accounts |

---

## 📞 SUPPORT CONTACTS

For deployment issues: admin@shifazahratextiles.com  
For technical support: [Your support number]  
Emergency hotline: [Your emergency number]

---

**Last Updated:** June 2026  
**Version:** 1.0.0
