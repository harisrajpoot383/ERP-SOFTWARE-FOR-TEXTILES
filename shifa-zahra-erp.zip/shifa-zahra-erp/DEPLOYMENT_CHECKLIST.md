# 🚀 DEPLOYMENT CHECKLIST

**Project:** Shifa Zahra Textiles ERP  
**Domain:** _______________________  
**Deployment Date:** _______________________  
**Deployed By:** _______________________  

---

## PRE-DEPLOYMENT (Preparation)

- [ ] Domain registered and pointing to hosting
- [ ] cPanel/Hosting account created
- [ ] SSH access confirmed (if needed)
- [ ] FTP/File Manager access confirmed
- [ ] MySQL hosting verified
- [ ] Backup of any existing website completed
- [ ] Project files extracted locally
- [ ] Database backup created (if upgrading existing system)

---

## STEP 1: FILE UPLOAD

- [ ] Login to cPanel File Manager
- [ ] Navigate to `public_html` folder
- [ ] Upload all project files
- [ ] Verify all folders created (app, resources, routes, storage, etc.)
- [ ] Check `.env.example` file exists
- [ ] Check database schema SQL file exists
- [ ] Verify `.htaccess` files in place

**Verification:** You should see folder structure like:
```
public_html/
├── app/
├── routes/
├── resources/
├── public/
├── database/
├── storage/
├── composer.json
├── .env.example
├── .htaccess
└── [other files]
```

---

## STEP 2: FOLDER PERMISSIONS

Set permissions via File Manager → Properties or SSH:

- [ ] `storage/` → 777 (Read/Write/Execute)
- [ ] `bootstrap/cache/` → 777
- [ ] `storage/backups/` → 777
- [ ] `storage/logs/` → 777
- [ ] `storage/framework/` → 777
- [ ] `public/uploads/` → 777 (if needed)
- [ ] All other folders → 755

**Command (SSH):**
```bash
chmod -R 777 storage bootstrap/cache public/uploads
chmod -R 755 app routes resources config database
```

---

## STEP 3: DATABASE SETUP

### Create Database

- [ ] Open MySQL Databases in cPanel
- [ ] Create new database: `shifa_zahra_erp`
- [ ] Create new user: `shifa_user`
- [ ] Set strong password: ________________
- [ ] Assign user to database
- [ ] Grant ALL privileges

**Database Details:**
- Database: `shifa_zahra_erp`
- Username: `shifa_user`
- Password: `________________`
- Host: `localhost`

### Import Schema

- [ ] Open phpMyAdmin
- [ ] Select database `shifa_zahra_erp`
- [ ] Go to **Import** tab
- [ ] Upload `database/schema.sql`
- [ ] Click **Go**
- [ ] Verify tables created (should see 40+ tables)

**Check in phpMyAdmin:**
```sql
SHOW TABLES;
-- Should return: roles, users, products, customers, sales, purchases, khata_entries, etc.
```

---

## STEP 4: ENVIRONMENT CONFIGURATION

- [ ] Copy `.env.example` to `.env`
- [ ] Edit `.env` file with correct values:
  ```
  APP_NAME="Shifa Zahra Textiles ERP"
  APP_ENV=production
  APP_KEY=base64:xxxxx (generate using console)
  APP_URL=https://yourdomain.com
  
  DB_HOST=localhost
  DB_PORT=3306
  DB_DATABASE=shifa_zahra_erp
  DB_USERNAME=shifa_user
  DB_PASSWORD=your_password_here
  
  MAIL_MAILER=smtp (optional, leave as is if not using)
  COMPANY_NAME="Shifa Zahra Textiles"
  CURRENCY=PKR
  ```

- [ ] Save `.env` file

**Critical Fields Check:**
```
✓ APP_KEY not empty
✓ DB_DATABASE = shifa_zahra_erp
✓ DB_USERNAME = shifa_user
✓ DB_PASSWORD = correct password
✓ APP_URL = https://yourdomain.com (not http://)
```

---

## STEP 5: APPLICATION KEY GENERATION

If APP_KEY is missing or `base64:`:

**Option A: Via cPanel Terminal/SSH**
```bash
cd /home/username/public_html
php artisan key:generate
```

**Option B: Via PHP**
Create file `generate_key.php`:
```php
<?php
echo 'base64:' . base64_encode(random_bytes(32));
?>
```

Copy output and paste into `.env` as `APP_KEY`

- [ ] APP_KEY generated and verified in `.env`

---

## STEP 6: SSL CERTIFICATE

- [ ] Open **AutoSSL** in cPanel
- [ ] Select your domain
- [ ] Install/force SSL
- [ ] Wait for completion (may take 15 minutes)
- [ ] Verify HTTPS works: `https://yourdomain.com`
- [ ] Check green padlock in browser
- [ ] Update `.env` to use `https://` URL

---

## STEP 7: DOCUMENT ROOT CONFIGURATION

- [ ] In cPanel, go to **Addon Domains** (or **Domains**)
- [ ] Find your domain
- [ ] Set **Document Root** to: `/public_html/public`
- [ ] Save changes
- [ ] Wait 5-10 minutes for propagation

**Verification:**
```
If you visit yourdomain.com, you should NOT see file listing.
You should see login page instead.
```

---

## STEP 8: FIRST ACCESS TEST

- [ ] Open browser → `https://yourdomain.com`
- [ ] Should see login page (not error)
- [ ] If blank page → check error logs in cPanel

**If ERROR:**
1. Check `storage/logs/laravel.log`
2. Verify database connection in `.env`
3. Ensure all PHP extensions installed
4. Contact hosting support if server error

- [ ] Login page loads successfully

---

## STEP 9: INITIAL LOGIN

- [ ] Enter email: `admin@shifazahratextiles.com`
- [ ] Enter password: `Admin@123456`
- [ ] Click **Sign In**
- [ ] Should see dashboard with analytics

**If login fails:**
- [ ] Check database has tables (phpMyAdmin)
- [ ] Verify users table has admin record
- [ ] Check `.env` database connection
- [ ] Check `storage/logs/laravel.log` for errors

---

## STEP 10: SECURITY SETUP

### Change Default Password

- [ ] Click user menu (top right) → "Change Password"
- [ ] Enter current: `Admin@123456`
- [ ] Enter new password (min 8 chars, with numbers & symbols)
- [ ] Confirm new password
- [ ] Save
- [ ] **Write new password:** ________________

- [ ] Login again with new password to confirm

### Create Admin User Account

- [ ] Go to **Settings** → **Users**
- [ ] Click **Add User**
- [ ] Name: ________________
- [ ] Email: ________________
- [ ] Role: **Super Admin**
- [ ] Password: ________________
- [ ] Save
- [ ] Login as this user to verify
- [ ] Logout

- [ ] Admin accounts created

### Disable Default Admin (Optional but Recommended)

- [ ] Go to **Settings** → **Users**
- [ ] Find `admin@shifazahratextiles.com`
- [ ] Click edit
- [ ] Uncheck **Is Active**
- [ ] Save

---

## STEP 11: CORE FUNCTIONALITY TEST

### Test POS System

- [ ] Go to **POS** → Point of Sale
- [ ] Select "Walk-in Customer"
- [ ] Search a product
- [ ] Add to cart
- [ ] Check total calculation
- [ ] Complete a test sale
- [ ] Print invoice
- [ ] Check sale appears in **Sales** list

- [ ] POS working ✓

### Test Khata Module

- [ ] Go to **Khata** → Customers
- [ ] Select any customer
- [ ] View ledger
- [ ] Add test entry
- [ ] Verify balance updated

- [ ] Khata working ✓

### Test Inventory

- [ ] Go to **Products** → List
- [ ] Verify products visible
- [ ] Check stock quantities
- [ ] Create adjustment
- [ ] Verify stock changed

- [ ] Inventory working ✓

### Test Backup

- [ ] Go to **Settings** → **Backup & Restore**
- [ ] Click **Create Backup**
- [ ] Wait for completion
- [ ] Download backup file
- [ ] Save to secure location

- [ ] Backup working ✓

---

## STEP 12: DATA IMPORT (If Needed)

If migrating from old system:

- [ ] Export old customer data (CSV/Excel)
- [ ] Import customers: **Customers** → **Import**
- [ ] Export old product data
- [ ] Import products: **Products** → **Import**
- [ ] Verify totals match
- [ ] Test opening balances

---

## STEP 13: EMAIL/NOTIFICATIONS (Optional)

- [ ] Go to **Settings** → **Email**
- [ ] Configure SMTP (if sending emails):
  - MAIL_MAILER=smtp
  - MAIL_HOST=smtp.gmail.com (or your provider)
  - MAIL_PORT=587
  - MAIL_USERNAME=your-email
  - MAIL_PASSWORD=app-password
- [ ] Test send email to admin
- [ ] Check email received

---

## STEP 14: MONITORING & LOGS

- [ ] Go to **Settings** → **Activity Log**
- [ ] Verify logs recording actions
- [ ] Check **Login Log** for access history

---

## STEP 15: FINAL CHECKS

### Performance

- [ ] Dashboard loads in < 3 seconds
- [ ] POS interface responsive
- [ ] Search/filter fast
- [ ] No console errors (check browser F12)

### Responsiveness

- [ ] Test on desktop browser ✓
- [ ] Test on tablet ✓
- [ ] Test on mobile phone ✓
- [ ] All buttons clickable

### Security

- [ ] SSL certificate active (green padlock) ✓
- [ ] Cannot access .env file directly
- [ ] Cannot access storage/logs directly
- [ ] Default password changed ✓
- [ ] Only necessary users have access

### Data Integrity

- [ ] Create sale → balance updates ✓
- [ ] Create expense → total changes ✓
- [ ] Stock adjustment → inventory updates ✓
- [ ] Payment received → Khata updates ✓

---

## STEP 16: TRAINING & HANDOFF

- [ ] User documentation printed/provided
- [ ] **QUICK_REFERENCE.md** shared with users
- [ ] Staff trained on POS usage
- [ ] Staff trained on Khata entry
- [ ] Backup procedure documented and tested
- [ ] Emergency contacts provided

---

## STEP 17: ONGOING MAINTENANCE

### Weekly

- [ ] Download and backup remote copy of database
- [ ] Check error logs for warnings
- [ ] Monitor disk space usage

### Monthly

- [ ] Test backup restore process
- [ ] Update staff access as needed
- [ ] Review activity logs for anomalies
- [ ] Test SSL certificate expiry date

### Quarterly

- [ ] Full system audit
- [ ] Review security logs
- [ ] Update documentation
- [ ] Plan for updates/upgrades

---

## CRITICAL REMINDERS

🚨 **NEVER SHARE:**
- `.env` file
- Database password
- Admin credentials
- Backup files (store securely)

🔐 **ALWAYS:**
- Change default admin password
- Keep backups off-site
- Monitor disk space
- Check logs regularly
- Keep SSL certificate renewed
- Update staff access when they leave

---

## SIGN-OFF

**Deployment Completed By:** _______________________  
**Date & Time:** _______________________  
**Verified By:** _______________________  
**Notes/Issues:** _______________________

---

## EMERGENCY CONTACTS

**Hosting Support:** _______________________  
**Technical Lead:** _______________________  
**Backup Location:** _______________________  

---

✅ **DEPLOYMENT COMPLETE**

System is now live and ready for business operations.
