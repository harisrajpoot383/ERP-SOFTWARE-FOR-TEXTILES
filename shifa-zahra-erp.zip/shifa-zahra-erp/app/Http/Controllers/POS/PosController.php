<?php

namespace App\Http\Controllers\POS;

use App\Http\Controllers\Controller;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\SalePayment;
use App\Models\SaleReturn;
use App\Models\ReturnItem;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\Customer;
use App\Models\Account;
use App\Models\Draft;
use App\Models\Coupon;
use App\Models\KhataEntry;
use App\Models\CashBook;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Barryvdh\DomPDF\Facade\Pdf;

class PosController extends Controller
{
    public function index()
    {
        $customers = Customer::where('is_active', 1)->orderBy('name')->get();
        $accounts  = Account::where('is_active', 1)->get();
        $categories = \App\Models\Category::where('is_active', 1)->orderBy('sort_order')->get();
        $held_sales = Draft::where('user_id', Auth::id())->where('type', 'sale')->count();
        $draft = Draft::where('user_id', Auth::id())->where('type', 'sale')->where('session_id', session()->getId())->first();

        return view('pos.index', compact('customers', 'accounts', 'categories', 'held_sales', 'draft'));
    }

    public function searchProducts(Request $request)
    {
        $query = $request->get('q', '');
        $products = Product::with('category', 'variants')
            ->where('is_active', 1)
            ->where(function ($q) use ($query) {
                $q->where('name', 'like', "%{$query}%")
                  ->orWhere('sku', 'like', "%{$query}%")
                  ->orWhere('barcode', 'like', "%{$query}%");
            })
            ->limit(20)
            ->get()
            ->map(function ($p) {
                return [
                    'id'       => $p->id,
                    'name'     => $p->name,
                    'sku'      => $p->sku,
                    'barcode'  => $p->barcode,
                    'price'    => $p->sale_price,
                    'stock'    => $p->stock_quantity,
                    'image'    => $p->image,
                    'category' => $p->category?->name,
                    'variants' => $p->variants,
                ];
            });

        return response()->json($products);
    }

    public function getProduct($id)
    {
        $product = Product::with('category', 'variants')->findOrFail($id);
        return response()->json([
            'id'              => $product->id,
            'name'            => $product->name,
            'sku'             => $product->sku,
            'barcode'         => $product->barcode,
            'sale_price'      => $product->sale_price,
            'wholesale_price' => $product->wholesale_price,
            'cost_price'      => $product->cost_price,
            'stock_quantity'  => $product->stock_quantity,
            'image'           => $product->image,
            'variants'        => $product->variants,
        ]);
    }

    public function scanBarcode($barcode)
    {
        $product = Product::where('barcode', $barcode)->with('variants')->first();
        if (!$product) {
            $variant = ProductVariant::where('barcode', $barcode)->with('product')->first();
            if ($variant) {
                return response()->json(['product' => $variant->product, 'variant' => $variant]);
            }
            return response()->json(['error' => 'Product not found'], 404);
        }
        return response()->json(['product' => $product]);
    }

    public function applyCoupon(Request $request)
    {
        $coupon = Coupon::where('code', $request->code)
            ->where('is_active', 1)
            ->where(function ($q) {
                $q->whereNull('valid_until')->orWhere('valid_until', '>=', today());
            })
            ->where(function ($q) {
                $q->whereNull('valid_from')->orWhere('valid_from', '<=', today());
            })
            ->first();

        if (!$coupon) {
            return response()->json(['error' => 'Invalid or expired coupon'], 422);
        }

        if ($coupon->usage_limit > 0 && $coupon->used_count >= $coupon->usage_limit) {
            return response()->json(['error' => 'Coupon usage limit reached'], 422);
        }

        $subtotal = $request->subtotal;
        if ($subtotal < $coupon->min_purchase) {
            return response()->json(['error' => "Minimum purchase of Rs. {$coupon->min_purchase} required"], 422);
        }

        $discount = $coupon->type === 'percent'
            ? ($subtotal * $coupon->value / 100)
            : $coupon->value;

        return response()->json([
            'discount'  => $discount,
            'type'      => $coupon->type,
            'value'     => $coupon->value,
            'code'      => $coupon->code,
        ]);
    }

    public function holdSale(Request $request)
    {
        Draft::updateOrCreate(
            ['user_id' => Auth::id(), 'type' => 'sale', 'session_id' => $request->hold_id ?? uniqid()],
            ['data' => json_encode($request->cart)]
        );

        return response()->json(['success' => true, 'message' => 'Sale held successfully']);
    }

    public function heldSales()
    {
        $drafts = Draft::where('user_id', Auth::id())->where('type', 'sale')->get();
        return response()->json($drafts);
    }

    public function resumeSale($id)
    {
        $draft = Draft::findOrFail($id);
        return response()->json(['cart' => json_decode($draft->data, true)]);
    }

    public function autoSave(Request $request)
    {
        Draft::updateOrCreate(
            [
                'user_id'    => Auth::id(),
                'type'       => 'sale',
                'session_id' => session()->getId(),
            ],
            ['data' => json_encode($request->all())]
        );

        return response()->json(['saved' => true, 'time' => now()->format('H:i:s')]);
    }

    public function getDraft()
    {
        $draft = Draft::where('user_id', Auth::id())
            ->where('type', 'sale')
            ->where('session_id', session()->getId())
            ->first();

        return response()->json($draft ? json_decode($draft->data, true) : null);
    }

    public function completeSale(Request $request)
    {
        $request->validate([
            'customer_id'    => 'required|exists:customers,id',
            'items'          => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity'   => 'required|integer|min:1',
            'items.*.unit_price' => 'required|numeric|min:0',
            'payments'       => 'required|array|min:1',
            'total_amount'   => 'required|numeric|min:0',
        ]);

        DB::beginTransaction();
        try {
            // Generate invoice number
            $prefix = Setting::getValue('invoice_prefix', 'SZT-');
            $last = Sale::max('id') ?? 0;
            $invoiceNo = $prefix . str_pad($last + 1, 6, '0', STR_PAD_LEFT);

            // Calculate totals
            $subtotal = collect($request->items)->sum(fn($i) => $i['quantity'] * $i['unit_price']);
            $discountAmt = $request->discount_amount ?? 0;
            $taxAmt      = $request->tax_amount ?? 0;
            $totalAmount = $subtotal - $discountAmt + $taxAmt + ($request->shipping ?? 0);
            $paidAmount  = collect($request->payments)->sum('amount');
            $balance     = $totalAmount - $paidAmount;
            $status      = $balance <= 0 ? 'paid' : ($paidAmount > 0 ? 'partial' : 'credit');

            // Create sale
            $sale = Sale::create([
                'invoice_number'  => $invoiceNo,
                'customer_id'     => $request->customer_id,
                'user_id'         => Auth::id(),
                'sale_date'       => today(),
                'subtotal'        => $subtotal,
                'discount_amount' => $discountAmt,
                'discount_percent'=> $request->discount_percent ?? 0,
                'tax_amount'      => $taxAmt,
                'tax_percent'     => $request->tax_percent ?? 0,
                'shipping_charges'=> $request->shipping ?? 0,
                'total_amount'    => $totalAmount,
                'paid_amount'     => $paidAmount,
                'balance_amount'  => max(0, $balance),
                'payment_status'  => $status,
                'sale_type'       => $request->sale_type ?? 'retail',
                'notes'           => $request->notes,
                'status'          => 'completed',
            ]);

            // Create sale items & update stock
            foreach ($request->items as $item) {
                $product = Product::findOrFail($item['product_id']);
                $lineDiscount = $item['discount_amount'] ?? 0;
                $lineTotal    = ($item['quantity'] * $item['unit_price']) - $lineDiscount;
                $profit       = $lineTotal - ($item['quantity'] * $product->cost_price);

                SaleItem::create([
                    'sale_id'         => $sale->id,
                    'product_id'      => $item['product_id'],
                    'variant_id'      => $item['variant_id'] ?? null,
                    'product_name'    => $product->name,
                    'sku'             => $product->sku,
                    'quantity'        => $item['quantity'],
                    'unit_price'      => $item['unit_price'],
                    'discount_amount' => $lineDiscount,
                    'tax_amount'      => $item['tax_amount'] ?? 0,
                    'total_price'     => $lineTotal,
                    'cost_price'      => $product->cost_price,
                    'profit'          => $profit,
                ]);

                // Deduct stock
                $product->decrement('stock_quantity', $item['quantity']);

                // Check low stock
                if ($product->stock_quantity <= $product->minimum_stock) {
                    \App\Models\Notification::create([
                        'type'    => 'low_stock',
                        'title'   => 'Low Stock Alert',
                        'message' => "{$product->name} is running low. Current stock: {$product->stock_quantity}",
                        'data'    => json_encode(['product_id' => $product->id]),
                    ]);
                }
            }

            // Process payments
            foreach ($request->payments as $payment) {
                if ($payment['amount'] <= 0) continue;

                SalePayment::create([
                    'sale_id'        => $sale->id,
                    'account_id'     => $payment['account_id'],
                    'amount'         => $payment['amount'],
                    'payment_method' => $payment['method'],
                    'reference'      => $payment['reference'] ?? null,
                ]);

                // Update account balance
                Account::where('id', $payment['account_id'])->increment('current_balance', $payment['amount']);

                // Cash book entry
                CashBook::create([
                    'account_id'       => $payment['account_id'],
                    'transaction_date' => today(),
                    'type'             => 'in',
                    'category'         => 'sale',
                    'amount'           => $payment['amount'],
                    'balance_after'    => Account::find($payment['account_id'])->current_balance,
                    'description'      => "Sale Invoice: {$invoiceNo}",
                    'reference_type'   => 'sale',
                    'reference_id'     => $sale->id,
                    'user_id'          => Auth::id(),
                ]);
            }

            // Update customer balance if credit sale
            if ($balance > 0) {
                $customer = \App\Models\Customer::find($request->customer_id);
                $customer->increment('current_balance', $balance);

                // Khata entry
                KhataEntry::create([
                    'party_type'     => 'customer',
                    'party_id'       => $request->customer_id,
                    'entry_type'     => 'debit',
                    'amount'         => $balance,
                    'balance_after'  => $customer->current_balance,
                    'description'    => "Credit sale - Invoice: {$invoiceNo}",
                    'reference_type' => 'sale',
                    'reference_id'   => $sale->id,
                    'entry_date'     => today(),
                    'user_id'        => Auth::id(),
                ]);
            }

            // Update coupon usage
            if ($request->coupon_code) {
                Coupon::where('code', $request->coupon_code)->increment('used_count');
            }

            // Clear auto-save draft
            Draft::where('user_id', Auth::id())->where('type', 'sale')->where('session_id', session()->getId())->delete();

            DB::commit();

            // Log activity
            activity_log('sale_created', 'Sale', $sale->id, "Sale {$invoiceNo} created for " . $sale->customer->name);

            return response()->json([
                'success'    => true,
                'sale_id'    => $sale->id,
                'invoice_no' => $invoiceNo,
                'message'    => 'Sale completed successfully',
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['error' => 'Sale failed: ' . $e->getMessage()], 500);
        }
    }

    public function invoice($id)
    {
        $sale = Sale::with('customer', 'items.product', 'payments', 'user')->findOrFail($id);
        $settings = Setting::getAll();
        return view('pos.invoice', compact('sale', 'settings'));
    }

    public function printInvoice($id)
    {
        $sale = Sale::with('customer', 'items.product', 'payments', 'user')->findOrFail($id);
        $settings = Setting::getAll();
        return view('pos.invoice-print', compact('sale', 'settings'));
    }

    public function thermalReceipt($id)
    {
        $sale = Sale::with('customer', 'items.product', 'payments')->findOrFail($id);
        $settings = Setting::getAll();
        return view('pos.thermal', compact('sale', 'settings'));
    }

    public function downloadPdf($id)
    {
        $sale = Sale::with('customer', 'items.product', 'payments', 'user')->findOrFail($id);
        $settings = Setting::getAll();
        $pdf = PDF::loadView('pos.invoice-pdf', compact('sale', 'settings'));
        return $pdf->download("Invoice-{$sale->invoice_number}.pdf");
    }

    public function processReturn(Request $request)
    {
        $request->validate([
            'sale_id' => 'required|exists:sales,id',
            'items'   => 'required|array|min:1',
            'reason'  => 'required|string',
        ]);

        DB::beginTransaction();
        try {
            $sale = Sale::findOrFail($request->sale_id);
            $returnNo = 'RET-' . str_pad(SaleReturn::count() + 1, 5, '0', STR_PAD_LEFT);
            $totalReturn = 0;

            $return = SaleReturn::create([
                'sale_id'       => $sale->id,
                'return_number' => $returnNo,
                'return_date'   => today(),
                'reason'        => $request->reason,
                'total_amount'  => 0, // updated below
                'refund_method' => $request->refund_method,
                'account_id'    => $request->account_id,
                'user_id'       => Auth::id(),
            ]);

            foreach ($request->items as $item) {
                $saleItem = SaleItem::findOrFail($item['sale_item_id']);
                $lineTotal = $item['quantity'] * $saleItem->unit_price;
                $totalReturn += $lineTotal;

                ReturnItem::create([
                    'return_id'   => $return->id,
                    'sale_item_id'=> $saleItem->id,
                    'product_id'  => $saleItem->product_id,
                    'quantity'    => $item['quantity'],
                    'unit_price'  => $saleItem->unit_price,
                    'total_price' => $lineTotal,
                    'restock'     => $item['restock'] ?? 1,
                ]);

                // Restock if requested
                if ($item['restock'] ?? 1) {
                    Product::where('id', $saleItem->product_id)->increment('stock_quantity', $item['quantity']);
                }
            }

            $return->update(['total_amount' => $totalReturn]);

            // Refund to account
            if ($request->account_id) {
                Account::where('id', $request->account_id)->decrement('current_balance', $totalReturn);
                CashBook::create([
                    'account_id'       => $request->account_id,
                    'transaction_date' => today(),
                    'type'             => 'out',
                    'category'         => 'sale',
                    'amount'           => $totalReturn,
                    'balance_after'    => Account::find($request->account_id)->current_balance,
                    'description'      => "Sale Return: {$returnNo}",
                    'reference_type'   => 'return',
                    'reference_id'     => $return->id,
                    'user_id'          => Auth::id(),
                ]);
            }

            DB::commit();
            return response()->json(['success' => true, 'return_no' => $returnNo]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
}
