<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\LoginLog;
use App\Models\FailedLoginAttempt;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;
use Carbon\Carbon;

class AuthController extends Controller
{
    private const MAX_ATTEMPTS = 5;
    private const LOCKOUT_MINUTES = 15;

    public function showLogin()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $request->validate([
            'email'    => 'required|email',
            'password' => 'required|string',
        ]);

        $ip = $request->ip();

        // Check brute force
        $blocked = FailedLoginAttempt::where('ip_address', $ip)
            ->where('attempts', '>=', self::MAX_ATTEMPTS)
            ->where('blocked_until', '>', now())
            ->first();

        if ($blocked) {
            $remaining = Carbon::parse($blocked->blocked_until)->diffInMinutes(now());
            return back()->withErrors([
                'email' => "Too many failed attempts. Try again in {$remaining} minutes.",
            ]);
        }

        // Attempt login
        if (Auth::attempt($request->only('email', 'password'), $request->boolean('remember'))) {
            $user = Auth::user();

            if (!$user->is_active) {
                Auth::logout();
                return back()->withErrors(['email' => 'Your account has been deactivated.']);
            }

            // Clear failed attempts
            FailedLoginAttempt::where('ip_address', $ip)->delete();

            // Update last login
            $user->update([
                'last_login_at' => now(),
                'last_login_ip' => $ip,
            ]);

            // Log login
            LoginLog::create([
                'user_id'    => $user->id,
                'email'      => $user->email,
                'ip_address' => $ip,
                'user_agent' => $request->userAgent(),
                'status'     => 'success',
                'created_at' => now(),
            ]);

            $request->session()->regenerate();

            if ($user->must_change_password) {
                return redirect()->route('password.change');
            }

            return redirect()->intended(route('dashboard'));
        }

        // Failed login
        LoginLog::create([
            'user_id'    => null,
            'email'      => $request->email,
            'ip_address' => $ip,
            'user_agent' => $request->userAgent(),
            'status'     => 'failed',
            'created_at' => now(),
        ]);

        // Increment failed attempts
        $attempt = FailedLoginAttempt::firstOrCreate(
            ['ip_address' => $ip],
            ['attempts' => 0, 'created_at' => now()]
        );
        $attempt->increment('attempts');
        $attempt->update(['updated_at' => now()]);

        if ($attempt->attempts >= self::MAX_ATTEMPTS) {
            $attempt->update([
                'blocked_until' => now()->addMinutes(self::LOCKOUT_MINUTES),
            ]);
            return back()->withErrors([
                'email' => 'Too many failed attempts. Account locked for ' . self::LOCKOUT_MINUTES . ' minutes.',
            ]);
        }

        $remaining = self::MAX_ATTEMPTS - $attempt->attempts;
        return back()->withErrors([
            'email' => "Invalid credentials. {$remaining} attempts remaining.",
        ])->withInput($request->only('email'));
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('login');
    }

    public function showChangePassword()
    {
        return view('auth.change-password');
    }

    public function changePassword(Request $request)
    {
        $request->validate([
            'password'              => 'required|string|min:8|confirmed',
            'password_confirmation' => 'required',
        ]);

        $user = Auth::user();

        if ($request->current_password && !Hash::check($request->current_password, $user->password)) {
            return back()->withErrors(['current_password' => 'Current password is incorrect']);
        }

        $user->update([
            'password'             => Hash::make($request->password),
            'must_change_password' => false,
        ]);

        return redirect()->route('dashboard')->with('success', 'Password changed successfully!');
    }
}
