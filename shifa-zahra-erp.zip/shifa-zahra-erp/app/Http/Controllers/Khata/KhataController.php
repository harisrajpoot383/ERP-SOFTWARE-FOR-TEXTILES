<?php

namespace App\Http\Controllers\Khata;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Supplier;
use App\Models\KhataEntry;
use App\Models\Account;
use App\Models\CashBook;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;

class KhataController extends Controller
{
    public function index()
    {
        $total_receivable = Customer::sum('current_balance');
        $total_payable    = Supplier::sum('current_balance');
        $recent_entries   = KhataEntry::with('customer', 'supplier')
            ->orderBy('created_at', 'desc')
            ->limit(20)
            ->get();

        $overdue_customers = Customer::where('current_balance', '>', 0)
            ->where('is_active', 1)
            ->orderByDesc('current_balance')
            ->limit(10)
            ->get();

        return view('khata.index', compact(
            'total_receivable', 'total_payable', 'recent_entries', 'overdue_customers'
        ));
    }

    public function customers(Request $request)
    {
        $query = Customer::where('is_active', 1);

        if ($request->search) {
            $query->where(function ($q) use ($request) {
                $q->where('name', 'like', "%{$request->search}%")
                  ->orWhere('phone', 'like', "%{$request->search}%");
            });
        }

        if ($request->balance_type === 'receivable') {
            $query->where('current_balance', '>', 0);
        } elseif ($request->balance_type === 'clear') {
            $query->where('current_balance', '<=', 0);
        }

        $customers = $query->orderBy('name')->paginate(20);
        return view('khata.customers', compact('customers'));
    }

    public function customerLedger(Request $request, $id)
    {
        $customer = Customer::findOrFail($id);

        $query = KhataEntry::where('party_type', 'customer')->where('party_id', $id);

        if ($request->from) {
            $query->where('entry_date', '>=', $request->from);
        }
        if ($request->to) {
            $query->where('entry_date', '<=', $request->to);
        }

        $entries = $query->orderBy('entry_date')->orderBy('id')->get();

        // Running balance
        $running_balance = $customer->opening_balance;
        foreach ($entries as $entry) {
            if ($entry->entry_type === 'debit') {
                $running_balance += $entry->amount;
            } else {
                $running_balance -= $entry->amount;
            }
            $entry->running_balance = $running_balance;
        }

        $summary = [
            'total_debit'  => $entries->where('entry_type', 'debit')->sum('amount'),
            'total_credit' => $entries->where('entry_type', 'credit')->sum('amount'),
            'balance'      => $customer->current_balance,
        ];

        return view('khata.customer-ledger', compact('customer', 'entries', 'summary'));
    }

    public function addCustomerEntry(Request $request, $id)
    {
        $request->validate([
            'entry_type'  => 'required|in:debit,credit',
            'amount'      => 'required|numeric|min:1',
            'description' => 'required|string',
            'entry_date'  => 'required|date',
        ]);

        DB::beginTransaction();
        try {
            $customer = Customer::findOrFail($id);

            // Update customer balance
            if ($request->entry_type === 'debit') {
                $customer->increment('current_balance', $request->amount);
            } else {
                $customer->decrement('current_balance', $request->amount);
                // If payment received, update account
                if ($request->account_id) {
                    Account::where('id', $request->account_id)->increment('current_balance', $request->amount);
                    CashBook::create([
                        'account_id'       => $request->account_id,
                        'transaction_date' => $request->entry_date,
                        'type'             => 'in',
                        'category'         => 'other',
                        'amount'           => $request->amount,
                        'balance_after'    => Account::find($request->account_id)->current_balance,
                        'description'      => "Payment received from {$customer->name}",
                        'reference_type'   => 'khata',
                        'reference_id'     => $id,
                        'user_id'          => Auth::id(),
                    ]);
                }
            }

            $entry = KhataEntry::create([
                'party_type'     => 'customer',
                'party_id'       => $id,
                'entry_type'     => $request->entry_type,
                'amount'         => $request->amount,
                'balance_after'  => $customer->current_balance,
                'description'    => $request->description,
                'entry_date'     => $request->entry_date,
                'user_id'        => Auth::id(),
            ]);

            DB::commit();
            return response()->json(['success' => true, 'entry' => $entry]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function suppliers(Request $request)
    {
        $query = Supplier::where('is_active', 1);

        if ($request->search) {
            $query->where(function ($q) use ($request) {
                $q->where('name', 'like', "%{$request->search}%")
                  ->orWhere('phone', 'like', "%{$request->search}%");
            });
        }

        $suppliers = $query->orderBy('name')->paginate(20);
        return view('khata.suppliers', compact('suppliers'));
    }

    public function supplierLedger(Request $request, $id)
    {
        $supplier = Supplier::findOrFail($id);

        $query = KhataEntry::where('party_type', 'supplier')->where('party_id', $id);

        if ($request->from) $query->where('entry_date', '>=', $request->from);
        if ($request->to)   $query->where('entry_date', '<=', $request->to);

        $entries = $query->orderBy('entry_date')->orderBy('id')->get();

        $running_balance = $supplier->opening_balance;
        foreach ($entries as $entry) {
            if ($entry->entry_type === 'credit') {
                $running_balance += $entry->amount;
            } else {
                $running_balance -= $entry->amount;
            }
            $entry->running_balance = $running_balance;
        }

        $summary = [
            'total_debit'  => $entries->where('entry_type', 'debit')->sum('amount'),
            'total_credit' => $entries->where('entry_type', 'credit')->sum('amount'),
            'balance'      => $supplier->current_balance,
        ];

        return view('khata.supplier-ledger', compact('supplier', 'entries', 'summary'));
    }

    public function addSupplierEntry(Request $request, $id)
    {
        $request->validate([
            'entry_type'  => 'required|in:debit,credit',
            'amount'      => 'required|numeric|min:1',
            'description' => 'required|string',
            'entry_date'  => 'required|date',
        ]);

        DB::beginTransaction();
        try {
            $supplier = Supplier::findOrFail($id);

            if ($request->entry_type === 'credit') {
                $supplier->increment('current_balance', $request->amount);
            } else {
                $supplier->decrement('current_balance', $request->amount);
                if ($request->account_id) {
                    Account::where('id', $request->account_id)->decrement('current_balance', $request->amount);
                    CashBook::create([
                        'account_id'       => $request->account_id,
                        'transaction_date' => $request->entry_date,
                        'type'             => 'out',
                        'category'         => 'purchase',
                        'amount'           => $request->amount,
                        'balance_after'    => Account::find($request->account_id)->current_balance,
                        'description'      => "Payment to {$supplier->name}",
                        'reference_type'   => 'khata',
                        'reference_id'     => $id,
                        'user_id'          => Auth::id(),
                    ]);
                }
            }

            $entry = KhataEntry::create([
                'party_type'     => 'supplier',
                'party_id'       => $id,
                'entry_type'     => $request->entry_type,
                'amount'         => $request->amount,
                'balance_after'  => $supplier->current_balance,
                'description'    => $request->description,
                'entry_date'     => $request->entry_date,
                'user_id'        => Auth::id(),
            ]);

            DB::commit();
            return response()->json(['success' => true, 'entry' => $entry]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function customerPdf($id)
    {
        $customer = Customer::findOrFail($id);
        $entries  = KhataEntry::where('party_type', 'customer')
            ->where('party_id', $id)
            ->orderBy('entry_date')
            ->get();

        $settings = \App\Models\Setting::getAll();
        $pdf = PDF::loadView('khata.customer-pdf', compact('customer', 'entries', 'settings'));
        return $pdf->download("Khata-{$customer->name}.pdf");
    }

    public function supplierPdf($id)
    {
        $supplier = Supplier::findOrFail($id);
        $entries  = KhataEntry::where('party_type', 'supplier')
            ->where('party_id', $id)
            ->orderBy('entry_date')
            ->get();

        $settings = \App\Models\Setting::getAll();
        $pdf = PDF::loadView('khata.supplier-pdf', compact('supplier', 'entries', 'settings'));
        return $pdf->download("Khata-{$supplier->name}.pdf");
    }

    public function summary()
    {
        $data = [
            'total_receivable' => Customer::sum('current_balance'),
            'total_payable'    => Supplier::sum('current_balance'),
            'top_debtors'      => Customer::where('current_balance', '>', 0)
                ->orderByDesc('current_balance')->limit(10)->get(),
            'top_creditors'    => Supplier::where('current_balance', '>', 0)
                ->orderByDesc('current_balance')->limit(10)->get(),
        ];
        return view('khata.summary', compact('data'));
    }
}
