<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Sale;
use App\Models\Purchase;
use App\Models\Product;
use App\Models\Customer;
use App\Models\Supplier;
use App\Models\Employee;
use App\Models\Expense;
use App\Models\Account;
use App\Models\KhataEntry;
use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        $today = Carbon::today();
        $yesterday = Carbon::yesterday();
        $weekStart = Carbon::now()->startOfWeek();
        $monthStart = Carbon::now()->startOfMonth();
        $yearStart = Carbon::now()->startOfYear();

        // Sales figures
        $stats = [
            'today_sales'     => Sale::whereDate('sale_date', $today)->where('status','completed')->sum('total_amount'),
            'yesterday_sales' => Sale::whereDate('sale_date', $yesterday)->where('status','completed')->sum('total_amount'),
            'week_sales'      => Sale::whereBetween('sale_date', [$weekStart, $today])->where('status','completed')->sum('total_amount'),
            'month_sales'     => Sale::whereBetween('sale_date', [$monthStart, $today])->where('status','completed')->sum('total_amount'),
            'year_sales'      => Sale::whereBetween('sale_date', [$yearStart, $today])->where('status','completed')->sum('total_amount'),
            'total_revenue'   => Sale::where('status','completed')->sum('total_amount'),

            // Profit
            'today_profit'    => Sale::whereDate('sale_date', $today)->where('status','completed')
                                    ->join('sale_items','sales.id','sale_items.sale_id')
                                    ->sum('sale_items.profit'),
            'month_profit'    => Sale::whereBetween('sale_date', [$monthStart, $today])->where('status','completed')
                                    ->join('sale_items','sales.id','sale_items.sale_id')
                                    ->sum('sale_items.profit'),
            'total_profit'    => Sale::where('status','completed')
                                    ->join('sale_items','sales.id','sale_items.sale_id')
                                    ->sum('sale_items.profit'),

            // Expenses
            'today_expenses'  => Expense::whereDate('expense_date', $today)->sum('amount'),
            'month_expenses'  => Expense::whereBetween('expense_date', [$monthStart, $today])->sum('amount'),
            'total_expenses'  => Expense::sum('amount'),

            // Counts
            'total_customers' => Customer::where('is_active', 1)->count(),
            'total_suppliers' => Supplier::where('is_active', 1)->count(),
            'total_employees' => Employee::where('is_active', 1)->count(),
            'total_products'  => Product::where('is_active', 1)->count(),

            // Low stock
            'low_stock_count' => Product::whereColumn('stock_quantity','<=','minimum_stock')
                                        ->where('is_active', 1)->count(),

            // Receivables / Payables
            'pending_receivables' => Customer::sum('current_balance'),
            'pending_payables'    => Supplier::sum('current_balance'),

            // Accounts
            'accounts' => Account::where('is_active', 1)->get(),

            // Notifications
            'unread_notifications' => Notification::where('is_read', 0)->count(),
        ];

        // Recent sales
        $recent_sales = Sale::with('customer')
            ->orderBy('created_at', 'desc')
            ->limit(10)
            ->get();

        // Top selling products this month
        $top_products = DB::table('sale_items')
            ->join('sales', 'sales.id', '=', 'sale_items.sale_id')
            ->join('products', 'products.id', '=', 'sale_items.product_id')
            ->whereBetween('sales.sale_date', [$monthStart, $today])
            ->where('sales.status', 'completed')
            ->select(
                'products.name',
                'products.sku',
                DB::raw('SUM(sale_items.quantity) as total_qty'),
                DB::raw('SUM(sale_items.total_price) as total_revenue'),
                DB::raw('SUM(sale_items.profit) as total_profit')
            )
            ->groupBy('products.id', 'products.name', 'products.sku')
            ->orderByDesc('total_qty')
            ->limit(10)
            ->get();

        // Low stock products
        $low_stock = Product::where('is_active', 1)
            ->whereColumn('stock_quantity', '<=', 'minimum_stock')
            ->with('category')
            ->orderBy('stock_quantity')
            ->limit(10)
            ->get();

        // Monthly sales chart data (last 12 months)
        $sales_chart = [];
        for ($i = 11; $i >= 0; $i--) {
            $month = Carbon::now()->subMonths($i);
            $sales_chart[] = [
                'month'  => $month->format('M Y'),
                'sales'  => Sale::whereYear('sale_date', $month->year)
                               ->whereMonth('sale_date', $month->month)
                               ->where('status', 'completed')
                               ->sum('total_amount'),
                'profit' => DB::table('sales')
                               ->join('sale_items', 'sales.id', 'sale_items.sale_id')
                               ->whereYear('sales.sale_date', $month->year)
                               ->whereMonth('sales.sale_date', $month->month)
                               ->where('sales.status', 'completed')
                               ->sum('sale_items.profit'),
            ];
        }

        // Category wise sales this month
        $category_sales = DB::table('sale_items')
            ->join('sales', 'sales.id', '=', 'sale_items.sale_id')
            ->join('products', 'products.id', '=', 'sale_items.product_id')
            ->join('categories', 'categories.id', '=', 'products.category_id')
            ->whereBetween('sales.sale_date', [$monthStart, $today])
            ->where('sales.status', 'completed')
            ->select('categories.name', DB::raw('SUM(sale_items.total_price) as total'))
            ->groupBy('categories.id', 'categories.name')
            ->orderByDesc('total')
            ->get();

        // Payment method breakdown today
        $payment_breakdown = DB::table('sale_payments')
            ->join('sales', 'sales.id', '=', 'sale_payments.sale_id')
            ->whereDate('sales.sale_date', $today)
            ->where('sales.status', 'completed')
            ->select('sale_payments.payment_method', DB::raw('SUM(sale_payments.amount) as total'))
            ->groupBy('sale_payments.payment_method')
            ->get();

        return view('dashboard.index', compact(
            'stats', 'recent_sales', 'top_products',
            'low_stock', 'sales_chart', 'category_sales', 'payment_breakdown'
        ));
    }

    public function getStats()
    {
        // AJAX endpoint for live stats refresh
        $today = Carbon::today();
        return response()->json([
            'today_sales'    => Sale::whereDate('sale_date', $today)->where('status','completed')->sum('total_amount'),
            'today_invoices' => Sale::whereDate('sale_date', $today)->where('status','completed')->count(),
            'cash_balance'   => Account::where('type','cash')->sum('current_balance'),
            'unread'         => Notification::where('is_read', 0)->count(),
        ]);
    }

    public function getCharts(Request $request)
    {
        $type = $request->get('type', 'monthly');
        // Return chart data as JSON for AJAX chart updates
        $data = [];

        if ($type === 'monthly') {
            for ($i = 11; $i >= 0; $i--) {
                $month = Carbon::now()->subMonths($i);
                $data[] = [
                    'label'   => $month->format('M'),
                    'sales'   => Sale::whereYear('sale_date', $month->year)
                                    ->whereMonth('sale_date', $month->month)
                                    ->where('status','completed')
                                    ->sum('total_amount'),
                    'expense' => Expense::whereYear('expense_date', $month->year)
                                       ->whereMonth('expense_date', $month->month)
                                       ->sum('amount'),
                ];
            }
        } elseif ($type === 'weekly') {
            for ($i = 6; $i >= 0; $i--) {
                $day = Carbon::now()->subDays($i);
                $data[] = [
                    'label' => $day->format('D'),
                    'sales' => Sale::whereDate('sale_date', $day)->where('status','completed')->sum('total_amount'),
                ];
            }
        }

        return response()->json($data);
    }
}
