<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\BackupLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Artisan;

class BackupController extends Controller
{
    private $backupPath;

    public function __construct()
    {
        $this->backupPath = storage_path('backups');
        if (!is_dir($this->backupPath)) {
            mkdir($this->backupPath, 0755, true);
        }
    }

    public function index()
    {
        $backups = BackupLog::orderByDesc('created_at')->paginate(20);
        $disk_usage = $this->getDiskUsage();
        return view('backup.index', compact('backups', 'disk_usage'));
    }

    public function create(Request $request)
    {
        try {
            $filename = $this->createBackup($request->get('type', 'manual'));
            return response()->json([
                'success'  => true,
                'filename' => $filename,
                'message'  => 'Backup created successfully',
            ]);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function createBackup(string $type = 'manual'): string
    {
        $timestamp = now()->format('Y-m-d_H-i-s');
        $filename  = "backup_{$timestamp}.sql";
        $filepath  = $this->backupPath . '/' . $filename;

        $host     = config('database.connections.mysql.host');
        $port     = config('database.connections.mysql.port', 3306);
        $database = config('database.connections.mysql.database');
        $username = config('database.connections.mysql.username');
        $password = config('database.connections.mysql.password');

        $command = "mysqldump --host={$host} --port={$port} --user={$username} "
                 . "--password={$password} {$database} > {$filepath}";

        exec($command, $output, $returnCode);

        if ($returnCode !== 0) {
            // Fallback: PHP-based backup
            $this->phpBackup($filepath, $database);
        }

        $size = file_exists($filepath) ? filesize($filepath) : 0;

        BackupLog::create([
            'filename'   => $filename,
            'size'       => $size,
            'type'       => $type,
            'status'     => 'success',
            'created_at' => now(),
        ]);

        // Keep only last 30 backups
        $this->cleanOldBackups();

        return $filename;
    }

    private function phpBackup(string $filepath, string $database): void
    {
        $tables = DB::select('SHOW TABLES');
        $output = "-- Shifa Zahra Textiles Database Backup\n";
        $output .= "-- Generated: " . now() . "\n\n";
        $output .= "SET FOREIGN_KEY_CHECKS=0;\n\n";

        foreach ($tables as $table) {
            $tableName = array_values((array)$table)[0];
            $output .= "DROP TABLE IF EXISTS `{$tableName}`;\n";

            $createTable = DB::select("SHOW CREATE TABLE `{$tableName}`");
            $output .= array_values((array)$createTable[0])[1] . ";\n\n";

            $rows = DB::table($tableName)->get();
            if ($rows->count() > 0) {
                $output .= "INSERT INTO `{$tableName}` VALUES\n";
                $rowData = [];
                foreach ($rows as $row) {
                    $values = array_map(function ($val) {
                        if ($val === null) return 'NULL';
                        return "'" . addslashes($val) . "'";
                    }, (array)$row);
                    $rowData[] = '(' . implode(',', $values) . ')';
                }
                $output .= implode(",\n", $rowData) . ";\n\n";
            }
        }

        $output .= "SET FOREIGN_KEY_CHECKS=1;\n";
        file_put_contents($filepath, $output);
    }

    public function download($filename)
    {
        $filepath = $this->backupPath . '/' . $filename;
        if (!file_exists($filepath)) {
            abort(404, 'Backup file not found');
        }
        return response()->download($filepath);
    }

    public function restore(Request $request, $filename)
    {
        $filepath = $this->backupPath . '/' . $filename;
        if (!file_exists($filepath)) {
            return response()->json(['error' => 'Backup file not found'], 404);
        }

        try {
            $host     = config('database.connections.mysql.host');
            $port     = config('database.connections.mysql.port', 3306);
            $database = config('database.connections.mysql.database');
            $username = config('database.connections.mysql.username');
            $password = config('database.connections.mysql.password');

            $command = "mysql --host={$host} --port={$port} --user={$username} "
                     . "--password={$password} {$database} < {$filepath}";

            exec($command, $output, $returnCode);

            if ($returnCode !== 0) {
                // PHP restore fallback
                $sql = file_get_contents($filepath);
                DB::unprepared($sql);
            }

            return response()->json(['success' => true, 'message' => 'Database restored successfully']);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function delete($filename)
    {
        $filepath = $this->backupPath . '/' . $filename;
        if (file_exists($filepath)) {
            unlink($filepath);
        }
        BackupLog::where('filename', $filename)->delete();
        return response()->json(['success' => true]);
    }

    private function getDiskUsage(): array
    {
        $files = glob($this->backupPath . '/*.sql');
        $total = array_sum(array_map('filesize', $files));
        return [
            'count' => count($files),
            'size'  => $this->formatBytes($total),
        ];
    }

    private function formatBytes(int $bytes): string
    {
        if ($bytes >= 1073741824) return round($bytes / 1073741824, 2) . ' GB';
        if ($bytes >= 1048576)   return round($bytes / 1048576, 2) . ' MB';
        if ($bytes >= 1024)      return round($bytes / 1024, 2) . ' KB';
        return $bytes . ' B';
    }

    private function cleanOldBackups(): void
    {
        $files = glob($this->backupPath . '/*.sql');
        if (count($files) > 30) {
            usort($files, fn($a, $b) => filemtime($a) - filemtime($b));
            $toDelete = array_slice($files, 0, count($files) - 30);
            foreach ($toDelete as $file) {
                unlink($file);
                BackupLog::where('filename', basename($file))->delete();
            }
        }
    }
}
