# SHIFA ZAHRA TEXTILES ERP - INSTALLATION GUIDE

**Version:** 1.0.0  
**Last Updated:** June 2026  
**Status:** Production Ready

---

## 📋 SYSTEM REQUIREMENTS

### Server Requirements (cPanel Hosting)
- **PHP:** 8.3 or higher
- **MySQL:** 5.7+ or MariaDB 10.3+
- **Disk Space:** Minimum 500 MB
- **Memory:** Minimum 256 MB (512 MB recommended)
- **Apache/Nginx:** Latest version with mod_rewrite enabled

### Local Development
- PHP 8.3
- Composer
- Node.js 18+ (optional, for frontend compilation)
- MySQL/MariaDB

---

## 🚀 DEPLOYMENT ON cPANEL HOSTING

### Step 1: Upload Files to cPanel

1. **Extract the ZIP file** on your local computer
2. **Login to cPanel** at `https://yourdomain.com:2083`
3. **Open File Manager** → Navigate to `public_html`
4. **Upload all files** from the project root (except `.env`)
5. **Set permissions:**
   - `storage/` folder: `777`
   - `bootstrap/cache/` folder: `777`
   - `public/` folder: `755`

### Step 2: Create MySQL Database in cPanel

1. Open **MySQL Databases** in cPanel
2. Create a new database: `shifa_zahra_erp`
3. Create a new user: `shifa_user`
4. Set a strong password
5. Assign user to database with ALL privileges
6. **Note down:** Database name, username, password

### Step 3: Configure Environment Variables

1. **Copy `.env.example` to `.env`**
   ```bash
   cp .env.example .env
   ```

2. **Edit `.env` file** via cPanel File Manager:
   ```
   APP_NAME="Shifa Zahra Textiles ERP"
   APP_ENV=production
   APP_KEY=base64:xxxxxxxxxxxxx
   APP_URL=https://yourdomain.com
   
   DB_CONNECTION=mysql
   DB_HOST=localhost
   DB_PORT=3306
   DB_DATABASE=shifa_zahra_erp
   DB_USERNAME=shifa_user
   DB_PASSWORD=your_password_here
   ```

3. Generate APP_KEY (copy from setup instructions)

### Step 4: Create Directories

Via SSH or File Manager, create these directories with 777 permissions:
```
storage/backups/
storage/logs/
storage/framework/cache/
storage/framework/sessions/
storage/framework/views/
bootstrap/cache/
```

### Step 5: Import Database

**Option A: Using phpMyAdmin (cPanel)**
1. Open **phpMyAdmin** in cPanel
2. Select your database
3. Go to **Import** tab
4. Select `database/schema.sql`
5. Click **Go**

**Option B: Using SSH (if available)**
```bash
mysql -u shifa_user -p shifa_zahra_erp < database/schema.sql
```

### Step 6: Configure .htaccess

**Ensure `.htaccess` in `public/` contains:**
```apache
<IfModule mod_rewrite.c>
    <IfModule mod_negotiation.c>
        Options -MultiViews
    </IfModule>

    RewriteEngine On

    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteRule ^ index.php [QSA,L]
</IfModule>
```

### Step 7: Setup SSL Certificate

1. Open **AutoSSL** in cPanel
2. Select your domain
3. Install SSL certificate
4. Update `APP_URL` in `.env` to `https://yourdomain.com`

### Step 8: Set Document Root

1. In cPanel, go to **Addon Domains** or **Domains**
2. Set document root to: `/public_html/public`

---

## 🔐 SECURING YOUR INSTALLATION

### 1. Change Default Admin Password
1. Login with: `admin@shifazahratextiles.com` / `Admin@123456`
2. **IMMEDIATELY change password** at Settings → Profile
3. Enable 2-Factor Authentication (recommended)

### 2. Restrict Access to Sensitive Files
Add to `.htaccess` in root:
```apache
<FilesMatch "^\.">
    Deny from all
</FilesMatch>

<FilesMatch "\.env$">
    Deny from all
</FilesMatch>

<FilesMatch "composer\.json$">
    Deny from all
</FilesMatch>
```

### 3. Enable CORS Headers
In cPanel:
1. Open **ModSecurity Tools**
2. Configure for your domain
3. Whitelist necessary origins

### 4. Setup Firewall Rules
1. **Backup Admin Panel** - restrict to known IPs
2. **Rate Limiting** - enabled for login page

### 5. Regular Backups
1. Use built-in backup system (Backup & Restore in Settings)
2. Download backups weekly and store securely
3. Test restore process monthly

---

## 📦 DATABASE SCHEMA OVERVIEW

### Key Tables (40+)
- **users** - System users with role-based access
- **products** - Inventory with variants
- **customers** - Customer ledger
- **suppliers** - Supplier accounts
- **sales** - Invoice records
- **purchases** - Purchase orders
- **khata_entries** - Digital ledger entries
- **accounts** - Cash, Bank, Easypaisa, JazzCash
- **expenses** - Daily expense tracking
- **employees** - Staff records with payroll
- **inventory_adjustments** - Stock movements
- **reports** - Audit trail

---

## 🎯 INITIAL SETUP CHECKLIST

After deployment:

- [ ] Access application at https://yourdomain.com
- [ ] Login with admin credentials
- [ ] Change admin password
- [ ] Configure company settings (Settings → General)
- [ ] Add categories (Products → Categories)
- [ ] Create sample products
- [ ] Add customers and suppliers
- [ ] Configure payment accounts (Accounting → Accounts)
- [ ] Create user accounts for staff
- [ ] Test POS system
- [ ] Test Khata module
- [ ] Create first backup
- [ ] Setup automated backups

---

## 🔧 TROUBLESHOOTING

### "MySQL connection refused"
- Check `DB_HOST`, `DB_USERNAME`, `DB_PASSWORD` in `.env`
- Ensure database user has privileges
- Check if MySQL port 3306 is accessible

### "Application key missing" error
- Run: `php artisan key:generate`
- Or manually set `APP_KEY` in `.env`

### 500 Internal Server Error
- Check `storage/logs/laravel.log` for errors
- Ensure `storage/` directory permissions are 777
- Verify `bootstrap/cache/` is writable

### Blank page after login
- Check error logs
- Ensure all views files are uploaded
- Verify database connection

### Can't upload files
- Check `public/` folder permissions
- Ensure `storage/` is writable
- Verify upload limits in php.ini

### Backup fails
- Ensure `storage/backups/` has 777 permissions
- Check MySQL credentials in `.env`
- Verify disk space available

---

## 📧 SUPPORT & CUSTOMIZATION

### Adding New Features
1. Create controller: `php artisan make:controller FeatureName`
2. Add routes in `routes/web.php`
3. Create views in `resources/views/`
4. Add migrations if needed

### Scheduled Tasks (Backups, Maintenance)
Add to cPanel **Cron Jobs**:
```
0 2 * * * curl https://yourdomain.com/backup/auto
0 3 * * 0 curl https://yourdomain.com/maintenance/cleanup
```

### Email Integration
Configure in `.env`:
```
MAIL_MAILER=smtp
MAIL_HOST=your-smtp-host
MAIL_PORT=587
MAIL_USERNAME=your-email
MAIL_PASSWORD=your-password
```

### WhatsApp Integration (Optional)
1. Get Twilio account
2. Add credentials to `.env`
3. Enable in Settings → Notifications

---

## 📞 CONTACT & UPDATES

- **Website:** shifazahratextiles.com
- **Email:** admin@shifazahratextiles.com
- **Support:** For deployment assistance

---

## ⚖️ LICENSE

This software is proprietary to Shifa Zahra Textiles. Unauthorized copying, modification, or distribution is strictly prohibited.

**Deployment Date:** _____________  
**Deployed By:** _____________  
**Notes:** _____________
