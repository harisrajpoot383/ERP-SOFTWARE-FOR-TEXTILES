<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Dashboard') — Shifa Zahra Textiles ERP</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">

    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Select2 -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">

    <!-- Toastr -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">

    <style>
        :root {
            --gold:        #B8960C;
            --gold-light:  #D4AF37;
            --gold-pale:   #F5EFD6;
            --black:       #0A0A0A;
            --charcoal:    #1C1C1C;
            --dark:        #2D2D2D;
            --mid:         #5A5A5A;
            --light:       #F7F5F0;
            --white:       #FFFFFF;
            --border:      #E8E3D8;
            --sidebar-w:   260px;
            --header-h:    64px;
            --radius:      12px;
            --shadow:      0 4px 24px rgba(0,0,0,0.08);
            --shadow-lg:   0 8px 40px rgba(0,0,0,0.14);
            --font-display: 'Cormorant Garamond', serif;
            --font-body:    'DM Sans', sans-serif;
            --red:    #DC3545;
            --green:  #198754;
            --blue:   #0D6EFD;
            --orange: #FD7E14;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: var(--font-body);
            background: var(--light);
            color: var(--charcoal);
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* ── SIDEBAR ── */
        .sidebar {
            position: fixed;
            top: 0; left: 0; bottom: 0;
            width: var(--sidebar-w);
            background: var(--black);
            z-index: 1000;
            overflow-y: auto;
            scrollbar-width: thin;
            scrollbar-color: var(--gold) transparent;
            transition: transform 0.3s ease;
        }

        .sidebar-brand {
            padding: 20px 24px 16px;
            border-bottom: 1px solid rgba(184,150,12,0.2);
        }

        .sidebar-brand img {
            height: 44px;
            filter: brightness(0) invert(1);
        }

        .sidebar-brand .tagline {
            font-size: 10px;
            letter-spacing: 2px;
            color: var(--gold);
            text-transform: uppercase;
            margin-top: 4px;
            font-weight: 500;
        }

        .sidebar-section {
            padding: 20px 0 8px;
        }

        .sidebar-section-label {
            padding: 0 24px 8px;
            font-size: 9px;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: rgba(255,255,255,0.3);
            font-weight: 600;
        }

        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 24px;
            color: rgba(255,255,255,0.65);
            text-decoration: none;
            font-size: 13.5px;
            font-weight: 400;
            transition: all 0.2s;
            border-left: 3px solid transparent;
        }

        .sidebar-link:hover,
        .sidebar-link.active {
            color: var(--gold-light);
            background: rgba(184,150,12,0.08);
            border-left-color: var(--gold);
        }

        .sidebar-link i {
            width: 18px;
            text-align: center;
            font-size: 14px;
            opacity: 0.8;
        }

        .sidebar-link .badge-count {
            margin-left: auto;
            background: var(--gold);
            color: var(--black);
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 20px;
            font-weight: 700;
        }

        /* Submenu */
        .sidebar-sub { display: none; background: rgba(0,0,0,0.3); }
        .sidebar-sub .sidebar-link { padding-left: 52px; font-size: 13px; }
        .has-sub > .sidebar-link::after {
            content: '\f107';
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            margin-left: auto;
            transition: transform 0.2s;
            font-size: 11px;
        }
        .has-sub.open > .sidebar-link::after { transform: rotate(180deg); }
        .has-sub.open > .sidebar-sub { display: block; }

        /* ── HEADER ── */
        .main-header {
            position: fixed;
            top: 0;
            left: var(--sidebar-w);
            right: 0;
            height: var(--header-h);
            background: var(--white);
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            padding: 0 28px;
            z-index: 900;
            gap: 16px;
            box-shadow: 0 1px 8px rgba(0,0,0,0.04);
        }

        .header-page-title {
            font-family: var(--font-display);
            font-size: 20px;
            font-weight: 600;
            color: var(--black);
            letter-spacing: 0.3px;
        }

        .header-right { margin-left: auto; display: flex; align-items: center; gap: 12px; }

        .header-icon-btn {
            width: 38px; height: 38px;
            border-radius: 50%;
            border: 1px solid var(--border);
            background: transparent;
            display: flex; align-items: center; justify-content: center;
            color: var(--mid);
            cursor: pointer;
            position: relative;
            transition: all 0.2s;
        }
        .header-icon-btn:hover { background: var(--light); color: var(--black); }

        .notif-badge {
            position: absolute;
            top: -2px; right: -2px;
            background: var(--red);
            color: white;
            font-size: 9px;
            width: 16px; height: 16px;
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-weight: 700;
        }

        .user-menu { display: flex; align-items: center; gap: 10px; cursor: pointer; }
        .user-avatar {
            width: 36px; height: 36px; border-radius: 50%;
            background: var(--gold);
            color: var(--black);
            display: flex; align-items: center; justify-content: center;
            font-weight: 700; font-size: 13px;
        }
        .user-name { font-size: 13px; font-weight: 500; color: var(--charcoal); }
        .user-role { font-size: 11px; color: var(--mid); }

        /* ── MAIN CONTENT ── */
        .main-content {
            margin-left: var(--sidebar-w);
            margin-top: var(--header-h);
            padding: 28px;
            min-height: calc(100vh - var(--header-h));
        }

        /* ── CARDS ── */
        .card {
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            overflow: hidden;
        }

        .card-header-custom {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .card-title {
            font-family: var(--font-display);
            font-size: 16px;
            font-weight: 600;
            color: var(--black);
        }

        .card-body-custom { padding: 20px; }

        /* ── STAT CARDS ── */
        .stat-card {
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 20px;
            position: relative;
            overflow: hidden;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 3px;
            background: var(--accent, var(--gold));
        }

        .stat-card .icon {
            width: 44px; height: 44px;
            border-radius: 10px;
            background: var(--icon-bg, rgba(184,150,12,0.1));
            color: var(--accent, var(--gold));
            display: flex; align-items: center; justify-content: center;
            font-size: 18px;
            margin-bottom: 14px;
        }

        .stat-card .label {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            color: var(--mid);
            font-weight: 600;
            margin-bottom: 4px;
        }

        .stat-card .value {
            font-family: var(--font-display);
            font-size: 26px;
            font-weight: 700;
            color: var(--black);
            line-height: 1;
        }

        .stat-card .sub {
            font-size: 12px;
            color: var(--mid);
            margin-top: 6px;
        }

        .stat-card .change {
            font-size: 12px;
            font-weight: 600;
            margin-top: 8px;
        }

        .change.up   { color: var(--green); }
        .change.down { color: var(--red); }

        /* ── TABLES ── */
        .table-custom { width: 100%; border-collapse: collapse; }
        .table-custom th {
            background: var(--light);
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 600;
            color: var(--mid);
            padding: 12px 16px;
            border-bottom: 2px solid var(--border);
            text-align: left;
        }
        .table-custom td {
            padding: 12px 16px;
            border-bottom: 1px solid var(--border);
            font-size: 13.5px;
            color: var(--charcoal);
        }
        .table-custom tbody tr:hover { background: var(--light); }
        .table-custom tbody tr:last-child td { border-bottom: none; }

        /* ── BADGES ── */
        .badge-status {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .badge-paid    { background: #d4edda; color: #155724; }
        .badge-partial { background: #fff3cd; color: #856404; }
        .badge-unpaid  { background: #f8d7da; color: #721c24; }
        .badge-credit  { background: #cce5ff; color: #004085; }

        /* ── BUTTONS ── */
        .btn-gold {
            background: var(--gold);
            color: var(--black);
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 13.5px;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-gold:hover {
            background: var(--gold-light);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(184,150,12,0.3);
        }

        .btn-outline-gold {
            background: transparent;
            color: var(--gold);
            border: 1.5px solid var(--gold);
            padding: 9px 18px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-outline-gold:hover {
            background: var(--gold);
            color: var(--black);
        }

        /* ── FORMS ── */
        .form-label-custom {
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--mid);
            margin-bottom: 6px;
        }

        .form-control-custom {
            border: 1.5px solid var(--border);
            border-radius: 8px;
            padding: 10px 14px;
            font-size: 14px;
            font-family: var(--font-body);
            color: var(--charcoal);
            width: 100%;
            background: var(--white);
            transition: border-color 0.2s;
            outline: none;
        }
        .form-control-custom:focus {
            border-color: var(--gold);
            box-shadow: 0 0 0 3px rgba(184,150,12,0.1);
        }

        /* ── AUTO-SAVE INDICATOR ── */
        #autosave-indicator {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 8px 16px;
            font-size: 12px;
            font-weight: 500;
            color: var(--mid);
            box-shadow: var(--shadow);
            display: none;
            align-items: center;
            gap: 8px;
            z-index: 9999;
        }
        #autosave-indicator.saving { color: var(--gold); display: flex; }
        #autosave-indicator.saved  { color: var(--green); display: flex; }

        /* ── ALERTS ── */
        .alert-gold {
            background: var(--gold-pale);
            border: 1px solid rgba(184,150,12,0.3);
            border-radius: 8px;
            padding: 14px 18px;
            font-size: 13.5px;
            color: #6B4F0A;
        }

        /* ── PAGE HEADER ── */
        .page-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
        }
        .page-header h1 {
            font-family: var(--font-display);
            font-size: 28px;
            font-weight: 700;
            color: var(--black);
        }
        .page-header .breadcrumb-custom {
            font-size: 12px;
            color: var(--mid);
            margin-top: 2px;
        }

        /* ── MOBILE ── */
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 16px; }
            .main-header { left: 0; }
            .stat-card .value { font-size: 20px; }
        }

        /* ── SCROLLBAR ── */
        ::-webkit-scrollbar { width: 5px; height: 5px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--gold); }
    </style>

    @stack('styles')
</head>
<body>

<!-- ── SIDEBAR ── -->
<nav class="sidebar" id="sidebar">
    <div class="sidebar-brand">
        <img src="{{ asset('images/logo.png') }}" alt="Shifa Zahra Textiles" onerror="this.style.display='none'; document.getElementById('brand-text').style.display='block'">
        <div id="brand-text" style="display:none; color:white; font-family:var(--font-display); font-size:18px; font-weight:600; letter-spacing:1px;">Shifa Zahra</div>
        <div class="tagline">Textiles ERP System</div>
    </div>

    <div class="sidebar-section">
        <div class="sidebar-section-label">Main</div>
        <a href="{{ route('dashboard') }}" class="sidebar-link {{ request()->routeIs('dashboard') ? 'active' : '' }}">
            <i class="fas fa-chart-pie"></i> Dashboard
        </a>
        <a href="{{ route('pos.index') }}" class="sidebar-link {{ request()->routeIs('pos.*') ? 'active' : '' }}">
            <i class="fas fa-cash-register"></i> POS — Point of Sale
        </a>
    </div>

    <div class="sidebar-section">
        <div class="sidebar-section-label">Ledger</div>
        <a href="{{ route('khata.index') }}" class="sidebar-link {{ request()->routeIs('khata.*') ? 'active' : '' }}">
            <i class="fas fa-book"></i> Digital Khata
        </a>
    </div>

    <div class="sidebar-section">
        <div class="sidebar-section-label">Inventory</div>
        <a href="{{ route('products.index') }}" class="sidebar-link {{ request()->routeIs('products.*') ? 'active' : '' }}">
            <i class="fas fa-boxes-stacked"></i> Products
        </a>
    </div>

    <div class="sidebar-section">
        <div class="sidebar-section-label">Transactions</div>
        <a href="{{ route('sales.index') }}" class="sidebar-link {{ request()->routeIs('sales.*') ? 'active' : '' }}">
            <i class="fas fa-arrow-up-right-dots"></i> Sales
        </a>
        <a href="{{ route('purchases.index') }}" class="sidebar-link {{ request()->routeIs('purchases.*') ? 'active' : '' }}">
            <i class="fas fa-truck-ramp-box"></i> Purchases
        </a>
        <a href="{{ route('expenses.index') }}" class="sidebar-link {{ request()->routeIs('expenses.*') ? 'active' : '' }}">
            <i class="fas fa-receipt"></i> Expenses
        </a>
    </div>

    <div class="sidebar-section">
        <div class="sidebar-section-label">Parties</div>
        <a href="{{ route('customers.index') }}" class="sidebar-link {{ request()->routeIs('customers.*') ? 'active' : '' }}">
            <i class="fas fa-users"></i> Customers
        </a>
        <a href="{{ route('suppliers.index') }}" class="sidebar-link {{ request()->routeIs('suppliers.*') ? 'active' : '' }}">
            <i class="fas fa-industry"></i> Suppliers
        </a>
        <a href="{{ route('employees.index') }}" class="sidebar-link {{ request()->routeIs('employees.*') ? 'active' : '' }}">
            <i class="fas fa-user-tie"></i> Employees
        </a>
    </div>

    <div class="sidebar-section">
        <div class="sidebar-section-label">Finance</div>
        <a href="{{ route('accounting.index') }}" class="sidebar-link {{ request()->routeIs('accounting.*') ? 'active' : '' }}">
            <i class="fas fa-calculator"></i> Accounting
        </a>
        <a href="{{ route('reports.index') }}" class="sidebar-link {{ request()->routeIs('reports.*') ? 'active' : '' }}">
            <i class="fas fa-chart-bar"></i> Reports
        </a>
    </div>

    @if(auth()->user()->role?->slug === 'super-admin')
    <div class="sidebar-section">
        <div class="sidebar-section-label">System</div>
        <a href="{{ route('settings.index') }}" class="sidebar-link {{ request()->routeIs('settings.*') ? 'active' : '' }}">
            <i class="fas fa-cog"></i> Settings
        </a>
        <a href="{{ route('backup.index') }}" class="sidebar-link {{ request()->routeIs('backup.*') ? 'active' : '' }}">
            <i class="fas fa-database"></i> Backup & Restore
        </a>
    </div>
    @endif

    <div style="height: 40px;"></div>
</nav>

<!-- ── HEADER ── -->
<header class="main-header">
    <button class="header-icon-btn d-md-none" id="sidebar-toggle">
        <i class="fas fa-bars"></i>
    </button>

    <div class="header-page-title">@yield('page-title', 'Dashboard')</div>

    <div class="header-right">
        <!-- Notifications -->
        <div class="dropdown">
            <button class="header-icon-btn" data-bs-toggle="dropdown">
                <i class="fas fa-bell"></i>
                @php $unread = \App\Models\Notification::where('is_read',0)->count(); @endphp
                @if($unread > 0)
                    <span class="notif-badge">{{ $unread > 9 ? '9+' : $unread }}</span>
                @endif
            </button>
            <div class="dropdown-menu dropdown-menu-end shadow" style="min-width:320px; border:1px solid var(--border); border-radius:12px; padding:0; overflow:hidden;">
                <div style="padding:14px 18px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center;">
                    <strong style="font-family:var(--font-display); font-size:15px;">Notifications</strong>
                    <a href="{{ route('notifications.read.all') }}" class="text-muted" style="font-size:12px;" onclick="event.preventDefault(); markAllRead();">Mark all read</a>
                </div>
                <div id="notifications-list" style="max-height:300px; overflow-y:auto;">
                    <div class="text-center text-muted p-4" style="font-size:13px;">Loading...</div>
                </div>
                <div style="padding:10px; border-top:1px solid var(--border); text-align:center;">
                    <a href="{{ route('notifications.index') }}" style="font-size:13px; color:var(--gold); text-decoration:none; font-weight:500;">View All</a>
                </div>
            </div>
        </div>

        <!-- Date/Time -->
        <div style="font-size:13px; color:var(--mid); display:none;" class="d-lg-block">
            <span id="current-time"></span>
        </div>

        <!-- User menu -->
        <div class="dropdown">
            <div class="user-menu" data-bs-toggle="dropdown">
                <div class="user-avatar">{{ strtoupper(substr(auth()->user()->name, 0, 1)) }}</div>
                <div class="d-none d-sm-block">
                    <div class="user-name">{{ auth()->user()->name }}</div>
                    <div class="user-role">{{ auth()->user()->role?->name ?? 'Admin' }}</div>
                </div>
                <i class="fas fa-chevron-down" style="font-size:11px; color:var(--mid);"></i>
            </div>
            <div class="dropdown-menu dropdown-menu-end shadow" style="min-width:200px; border:1px solid var(--border); border-radius:12px;">
                <a class="dropdown-item" href="{{ route('settings.index') }}" style="font-size:13.5px; padding:10px 16px;">
                    <i class="fas fa-user me-2" style="width:16px; color:var(--gold);"></i> Profile
                </a>
                <a class="dropdown-item" href="{{ route('password.change') }}" style="font-size:13.5px; padding:10px 16px;">
                    <i class="fas fa-key me-2" style="width:16px; color:var(--gold);"></i> Change Password
                </a>
                <hr class="dropdown-divider">
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="dropdown-item" style="font-size:13.5px; padding:10px 16px; color:var(--red);">
                        <i class="fas fa-sign-out-alt me-2" style="width:16px;"></i> Sign Out
                    </button>
                </form>
            </div>
        </div>
    </div>
</header>

<!-- ── MAIN CONTENT ── -->
<main class="main-content">
    <!-- Flash Messages -->
    @if(session('success'))
        <div class="alert-gold mb-4" role="alert">
            <i class="fas fa-check-circle me-2"></i> {{ session('success') }}
        </div>
    @endif
    @if(session('error'))
        <div class="alert alert-danger mb-4 rounded-3" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i> {{ session('error') }}
        </div>
    @endif

    @yield('content')
</main>

<!-- Auto-save indicator -->
<div id="autosave-indicator">
    <i class="fas fa-circle-notch fa-spin" id="autosave-icon"></i>
    <span id="autosave-text">Saving...</span>
</div>

<!-- Mobile sidebar overlay -->
<div id="sidebar-overlay" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:999;" onclick="closeSidebar()"></div>

<!-- ── SCRIPTS ── -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/numeral@2.0.6/numeral.min.js"></script>

<script>
// CSRF setup
$.ajaxSetup({
    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }
});

// Toastr config
toastr.options = {
    positionClass: 'toast-bottom-right',
    timeOut: 3500,
    closeButton: true,
    progressBar: true,
};

// Clock
function updateClock() {
    const now = new Date();
    document.getElementById('current-time').textContent =
        now.toLocaleDateString('en-PK', { weekday:'short', day:'2-digit', month:'short' }) +
        ' ' + now.toLocaleTimeString('en-PK', { hour:'2-digit', minute:'2-digit' });
}
setInterval(updateClock, 1000);
updateClock();

// Sidebar mobile toggle
function openSidebar() {
    document.getElementById('sidebar').classList.add('open');
    document.getElementById('sidebar-overlay').style.display = 'block';
}
function closeSidebar() {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebar-overlay').style.display = 'none';
}
document.getElementById('sidebar-toggle')?.addEventListener('click', openSidebar);

// Submenu toggles
document.querySelectorAll('.has-sub > .sidebar-link').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        this.parentElement.classList.toggle('open');
    });
});

// Load notifications
function loadNotifications() {
    fetch('{{ route("notifications.count") }}')
        .then(r => r.json())
        .then(data => {
            const badge = document.querySelector('.notif-badge');
            if (badge) badge.textContent = data.count > 9 ? '9+' : data.count;
        });
}

// Format PKR
function formatPKR(amount) {
    return 'Rs. ' + numeral(amount).format('0,0.00');
}

// Auto-save helper
function showAutoSave(state, text) {
    const el = document.getElementById('autosave-indicator');
    const icon = document.getElementById('autosave-icon');
    const txt = document.getElementById('autosave-text');
    el.className = state;
    icon.className = state === 'saving'
        ? 'fas fa-circle-notch fa-spin'
        : 'fas fa-check-circle';
    txt.textContent = text;
    if (state === 'saved') {
        setTimeout(() => { el.style.display = 'none'; }, 3000);
    }
}

function markAllRead() {
    $.post('{{ route("notifications.read.all") }}', function() {
        loadNotifications();
        toastr.success('All notifications marked as read');
    });
}

// Refresh notifications every 30 seconds
setInterval(loadNotifications, 30000);

// Global number formatter
window.pkr = (n) => 'Rs. ' + parseFloat(n || 0).toLocaleString('en-PK', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
</script>

@stack('scripts')
</body>
</html>
